-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: project
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mlcppuequzpbhanemkiexlbyhhasjecdjgum` (`primaryOwnerId`),
  CONSTRAINT `fk_mlcppuequzpbhanemkiexlbyhhasjecdjgum` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nentbakcoimohvmphnoadtulsodrrhketlow` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_epndtsjplpmztcknenomvabqlbvmwwpoymce` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_qdkpxvxlzbwwialmidlslhmrurlgcuydefse` (`dateRead`),
  KEY `fk_cmkrsvroodqtrruzqvatexgauoyilzjkokqm` (`pluginId`),
  CONSTRAINT `fk_cmkrsvroodqtrruzqvatexgauoyilzjkokqm` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tqlbrbrhrhmedrnkdjfjtlxatnvcjoafxtqs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qwzgjdywbulyvhfioncnztdnvgfdgeeptvpp` (`sessionId`,`volumeId`),
  KEY `idx_emeosnnvshneespzaymzhvpgqezugzhrksyj` (`volumeId`),
  CONSTRAINT `fk_buixkfgkbantqzxfogjaqwyfwmumpnegilrn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dbtmzhfdmixkojjxmxgdvhpjuahcozcntwet` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xruusfifmqkzvbzknqsoavnlsqtaxtbiutlw` (`filename`,`folderId`),
  KEY `idx_yrdjazqqhkzwxgrclenddifoyabnqxynmnkv` (`folderId`),
  KEY `idx_avymncaocjdybkwggjjalvwmfcsceggmgfbr` (`volumeId`),
  KEY `fk_deymsbmxkunegyjvcktedinmadvctipddvuc` (`uploaderId`),
  CONSTRAINT `fk_deymsbmxkunegyjvcktedinmadvctipddvuc` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lafqnmlfuvmanrqkmmjyhmujpmvimnermphw` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjolvwuacaovesgqklplbdutrvjgqxfubusu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xhszhvueiwnjdwspphuofckdskyjwnzsurok` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_jxuooqumnbajxicasskrjjdcrlkzlzdwvdrl` (`siteId`),
  CONSTRAINT `fk_jxuooqumnbajxicasskrjjdcrlkzlzdwvdrl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qovnjlunubjjrpacsztteeqmiruubqfnpodo` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vteuexejoxwbwuzkqexnkfioaesulegsspny` (`userId`),
  CONSTRAINT `fk_vteuexejoxwbwuzkqexnkfioaesulegsspny` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yohixoddfwdwdwktqpoukxlbkbpfntqrdzeg` (`groupId`),
  KEY `fk_ufefettjgmttklutpahhkxgbpxjtfpcvccoe` (`parentId`),
  CONSTRAINT `fk_lwamwpygmjrpnqqnyriccjysdwcsqkpwqfri` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pmtzhgovfrjtrsxzqzkcupiemowthtkakhos` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ufefettjgmttklutpahhkxgbpxjtfpcvccoe` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dbuaqjxfpgjiqolpnyphhukvyszzvjbdiweb` (`name`),
  KEY `idx_eklkvtxnpfmbeirmhfwnhraazctzzdcyvsjt` (`handle`),
  KEY `idx_xmekjtyufqvsaojalrzuagwprtrnchogkzbj` (`structureId`),
  KEY `idx_rayktcdiphvrmoqgjachnencyesyjawocvgc` (`fieldLayoutId`),
  KEY `idx_vmivvhqzxlddbqavrkdertzmbqpwklrscbvu` (`dateDeleted`),
  CONSTRAINT `fk_pvnpgexkukyekznkatptxubaxvqlagnqgzbm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wpzvnhyjhhqoubrcnprtkjpvqonqwhfnpyeb` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ucrkrompcifeisdynisagairgftolmfpqgcv` (`groupId`,`siteId`),
  KEY `idx_ljizvimbtpdjxnfmqtwvgphxnqbdfkmvyiyk` (`siteId`),
  CONSTRAINT `fk_pjnxlplttdpoujgloqlullibrrwueupniqef` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wbfxxkfhbrkiozkenlpxzpjoinsruyyrsilz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_yyuazrppfnqblagtztfogefjbnxbnixtjlgt` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_gojbsmzqqzayhxxlzsoqiywjjeyulkasqbjb` (`siteId`),
  KEY `fk_eihqcyisgyyvpqrttmfofrdguwokjiwhvbwz` (`userId`),
  CONSTRAINT `fk_eihqcyisgyyvpqrttmfofrdguwokjiwhvbwz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_gojbsmzqqzayhxxlzsoqiywjjeyulkasqbjb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zdwzztixnuqehsdvmwshakyaosvoocbbpbnt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_jtgrrugdsvviqznyuifkzyiisvavhialnouw` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_lkelvfhtiwfwnjfxlfuaohfkrcjvhlnmocph` (`siteId`),
  KEY `fk_swqpoxopvqctkaobkfnppojjaejtvpdjaixy` (`fieldId`),
  KEY `fk_ixbgusrmietqfnzjcvakhrxzmexjkzsqjfux` (`userId`),
  CONSTRAINT `fk_ixbgusrmietqfnzjcvakhrxzmexjkzsqjfux` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_lkelvfhtiwfwnjfxlfuaohfkrcjvhlnmocph` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_swqpoxopvqctkaobkfnppojjaejtvpdjaixy` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vjjzvyugtezqaoiemxeyxzpvjxrewwrigigw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hhkitqlnbwlzfmolpcrmkkdrqwrfcvswmpew` (`userId`),
  CONSTRAINT `fk_hhkitqlnbwlzfmolpcrmkkdrqwrfcvswmpew` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qkqxjdiizhwyjzvueqsvmyfilmzhyugcfoma` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_ydpupanxnyndbjbxpgfnmwpeujreitasbipn` (`creatorId`,`provisional`),
  KEY `idx_edzegqibcenaoxraqgbipiinpfqairzxalhj` (`saved`),
  KEY `fk_jdyhwqbxlrlvmrdqmxdoyqwhenjodxuoldhg` (`canonicalId`),
  CONSTRAINT `fk_jdyhwqbxlrlvmrdqmxdoyqwhenjodxuoldhg` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rowpsjfddwywwpdwtmloghzclvbokwoycmfb` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_towmsgbbrcikujpgvvvvywaazooyqexvwmkr` (`elementId`,`timestamp`,`userId`),
  KEY `fk_guvsxcuhrvdozqtmkolsjdpnwdgavhcmwqfi` (`userId`),
  KEY `fk_dfxplcvrwedazpknrupdcjeulhaxwlfjmyuw` (`siteId`),
  KEY `fk_tuhpioxgywcqqzkywioisjzjpgyovsqshwgs` (`draftId`),
  CONSTRAINT `fk_dfxplcvrwedazpknrupdcjeulhaxwlfjmyuw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_guvsxcuhrvdozqtmkolsjdpnwdgavhcmwqfi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tuhpioxgywcqqzkywioisjzjpgyovsqshwgs` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvikqgyhscbfvkebhjpnftbzslmmxqvahbac` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vnoangbillfcexrrevwicjkmjshyedklkeyk` (`dateDeleted`),
  KEY `idx_bgbeticgbabzveobimpkwykhlfiuxeebmjci` (`fieldLayoutId`),
  KEY `idx_wbkscvibrvqphvgdeolcpfrqpjwueftusucg` (`type`),
  KEY `idx_bdresdhtoacfniqybycjssqlmpzhffyptput` (`enabled`),
  KEY `idx_ugetnxonobfkuhxuwvwbuearuodhessgaebp` (`canonicalId`),
  KEY `idx_obcwcppddsaygijcgdghwkaavbbijshpzbam` (`archived`,`dateCreated`),
  KEY `idx_ctwvmwfxqygomwlgpamhsnnilxumsrqprkwo` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_baklpbdfpprndcpgiodsuezaxlhfdsjuieri` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_jnihowcsassroyqvijihrwbajltackvsxnkk` (`draftId`),
  KEY `fk_wxqftkjwzbafptvsvcgcldrcoilmlhpihree` (`revisionId`),
  CONSTRAINT `fk_jnihowcsassroyqvijihrwbajltackvsxnkk` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kcqwhfhdxiaqchloomourzlxsxpxqrhlwjwz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wxqftkjwzbafptvsvcgcldrcoilmlhpihree` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zpqmftbutwiebmuutbmgntadtjlohcwnmxyh` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_bnafbtnyojttxbiavisqgbwyugcdlnlgewnl` (`timestamp`),
  CONSTRAINT `fk_kundrxwvaoosnthazibiimnnoxgtnrcrszuv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_cpmzjqrtgkmbowzfvxvhmpwiunuvokqdhaie` (`ownerId`),
  CONSTRAINT `fk_cpmzjqrtgkmbowzfvxvhmpwiunuvokqdhaie` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hgkyftjjhcekgegzevmzqoxndjatuaqqwojg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vsoykwcthifvlrpfyxioxjdzbpbxnlwadgar` (`elementId`,`siteId`),
  KEY `idx_uoakclsdoizgxukrbpjqhcefylvolzlfymww` (`siteId`),
  KEY `idx_xaxlhviusuvxxnxstouhxguvkabkoxcaeifk` (`title`,`siteId`),
  KEY `idx_ibanqznlitdvtfrsuvkcoptqnajqkayabwvd` (`slug`,`siteId`),
  KEY `idx_jmrndjhurhwyutefvpmccwxgvddmnpmbnzqq` (`enabled`),
  KEY `idx_fbgvcmfbfkwozquqfcbdkdsyskcibxlfjyuu` (`uri`,`siteId`),
  CONSTRAINT `fk_dtzpavxhvzbzwajlcczkntfodeimnucpygkw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wwesvrivaqnyccmgyxzgxawkuyfynfnrkdea` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nugmgbakcrvouokpicsboromumahqsnxmdva` (`postDate`),
  KEY `idx_qksmiynwrqilfzvlxvkoaevsqfyaqggihgff` (`expiryDate`),
  KEY `idx_ndbophrlogegkdxddplbkrzpwntckwrorxlb` (`sectionId`),
  KEY `idx_juahumypetnvvyolhtaczpozgsizfwhqdcka` (`typeId`),
  KEY `idx_whgcofjncuipigbzfwnblwtjqnhkzjkjyaqk` (`primaryOwnerId`),
  KEY `idx_msobdxknlkchgqriwccrmanogrgtvngoniqr` (`fieldId`),
  KEY `fk_zxfmfhnkgswsdpbmiqphsmcdoonwuzjmmgph` (`parentId`),
  CONSTRAINT `fk_esboxlodrudekuuaubxcnxdyhxchomnvmzff` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_estgblyxkfyjtagriscexobfxwpmolptfvhz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fuumsdrusuukwzvwaevtqpemflsudxublccj` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pjrxosnnqquflpfvxbmcihlalyuzuixmzawb` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xkmauifcxbbdzwnpwmiecinymxuopcrefzrd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxfmfhnkgswsdpbmiqphsmcdoonwuzjmmgph` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_dfhnlijsnkdpwjltyfbualugatntuonnlatc` (`authorId`),
  KEY `idx_amzrrbfjheebnyqvyktuhumdudzhpcbewlje` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_fhkbiqvnyjqclhxdscurqqozroxqbhwyfxtg` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lqvktcguourzhszhrgjziqykrsavpdvlkahw` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ovkgkmilprnwvnvshjvuqwcsksokrbuibrjv` (`fieldLayoutId`),
  KEY `idx_nzmyooyybojhjzghfiooxfsbjnyirtrhxpuy` (`dateDeleted`),
  CONSTRAINT `fk_fwbnrtgnkikztqkedapmflxzojoaewylgxyo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_njiqepzhyiwnsskpopjsbplvvcstzgiuukyt` (`dateDeleted`),
  KEY `idx_zqgniusyseyrunuwuwabotnfvgclcrturjth` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tptmwcnoevfcufuvpeytqjmzeacasksyvuuw` (`handle`,`context`),
  KEY `idx_bapysqjegsgpenciyvmcqrnbvgeevqwnsvsn` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nfpaismvvekuybselbnwgsxxtdfcjphekkoj` (`name`),
  KEY `idx_odmjucuvghhyxsenkegirrffprxqefwshogf` (`handle`),
  KEY `idx_wfvogrzbzrilzjywcxusnpzqfjjokrduwzsm` (`fieldLayoutId`),
  KEY `idx_cpbecusrjpdrjfsmomstuofwhyiqtyytmvsz` (`sortOrder`),
  CONSTRAINT `fk_ahqloxdvlfkjhuquyrpnyevrwoshngcwwhbe` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ncpibtqjcfjxttngunnhcfqjluewgmywsnrv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ymjejqtrrvzrujofyjtmaxltalvhpfbxdoir` (`accessToken`),
  UNIQUE KEY `idx_goqxiariibhpbzlwqzzochvyecydahytkbdb` (`name`),
  KEY `fk_yfztzeaqaxxicdiipyhoajwqhzausrctkyxf` (`schemaId`),
  CONSTRAINT `fk_yfztzeaqaxxicdiipyhoajwqhzausrctkyxf` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mvijypfmmjmsqzxeqgmpekurqsltxycreugr` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nhfxoqaukzienmzxcayykprkvotvckqkhkxi` (`name`),
  KEY `idx_gjonwlwofvkopaxaxveonpwiannlovwfokiw` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cjycckkuvuttplwnmnscuyukfbryyaabnkja` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `navigation_navs`
--

DROP TABLE IF EXISTS `navigation_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation_navs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `instructions` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `maxNodes` int DEFAULT NULL,
  `maxNodesSettings` text,
  `permissions` text,
  `fieldLayoutId` int DEFAULT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_neqgkutmrfojcvcuutslufpuetyszvqrvqxb` (`handle`),
  KEY `idx_gchtkfyaxesosdflvevudpyubohibacpouyj` (`structureId`),
  KEY `idx_oxgjxsofarbxhterqgcwknnwhlstnjkjubjf` (`fieldLayoutId`),
  KEY `idx_lppbwptkpfevlumexcttxabvnvfysogxdlqd` (`dateDeleted`),
  CONSTRAINT `fk_knvmyxvujdjkebpoluolhtwfuiirnggbuzxb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ychpwyasuguaonlmmxyndhldlvhdfgusywpl` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `navigation_navs_sites`
--

DROP TABLE IF EXISTS `navigation_navs_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation_navs_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `navId` int NOT NULL,
  `siteId` int NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_imnqseoislnptpxiszsggnqyrywhdzygzyqm` (`navId`,`siteId`),
  KEY `idx_wlfmkqizqwtdqjvagogbalmvkwaehqfbryna` (`siteId`),
  CONSTRAINT `fk_ojfubzirjmziubzidqgdhvczntwjjxrjqjep` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tdevflkysaokrsycsfxzuehvuketmrgimymg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `navigation_nodes`
--

DROP TABLE IF EXISTS `navigation_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation_nodes` (
  `id` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `navId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `classes` varchar(255) DEFAULT NULL,
  `urlSuffix` varchar(255) DEFAULT NULL,
  `customAttributes` text,
  `data` text,
  `newWindow` tinyint(1) DEFAULT '0',
  `deletedWithNav` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ixdxbwnuywnwqpyhcnzbnwwgpesaztsozvzh` (`navId`),
  KEY `fk_uxbbssujxbrzvtynjqznjindyadqtpeehrfs` (`elementId`),
  CONSTRAINT `fk_sqdvtgsyxkccvbrctvnszresdjqnbrgsbgkm` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uxbbssujxbrzvtynjqznjindyadqtpeehrfs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vlvcipphpegxtefuatxckqiwylodbclrocqb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fybcmzdfkewrzadgowoehkzcyeegdbagwlhx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_qvvpmajhhypoaxsapcwcalsrftzjyghafspv` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_rhlssdmjmosrqfsxdbkbumijvwltmxghnadf` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aqsobyjefvgtlejxipemmktaksdcbzsilfqw` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_lrgxavaxwrfkfpuanowcklzgwamdmxcqwsxo` (`sourceId`),
  KEY `idx_ccodqxhwmbflxsluprruoyefnferlosltmfb` (`targetId`),
  KEY `idx_rckoonxyanzmjwuesxlccjraiawxtolsovck` (`sourceSiteId`),
  CONSTRAINT `fk_hbupxctbakbtnfeucchqrrovdjcvvtcorhsk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invxrfnnhsbqhfrwsreafmceyagnxgraogsl` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_slqpsxhldaizlaentckhayzirbxubozpecut` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mhkmmthkckhitzictbduyimzvwkgnungwwly` (`canonicalId`,`num`),
  KEY `fk_nmydlwejenoizznibihzeiqejicgieivucpx` (`creatorId`),
  CONSTRAINT `fk_nmydlwejenoizznibihzeiqejicgieivucpx` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nxxdwguanqqkgsjeewwdrzomkplexdjskisc` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_dfsulogwoxnaqyumaijiacfzxoaazcnftmrv` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_etiokrdhmexqmruotjvlmyglhjkfxqmihjjq` (`handle`),
  KEY `idx_okehknwojrfbseaedpmzfjhmxxhpjoziyfcj` (`name`),
  KEY `idx_trcmclmhlgsmroobkqhdevtcpoysvfftwxfd` (`structureId`),
  KEY `idx_qsovokgpyubpyvtbgnjmylhtcqihjencznox` (`dateDeleted`),
  CONSTRAINT `fk_ylehbmpldsrnpupgjuenretlrhhftxmwmvdk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_qgxsrfvxrckuapavzcdvfrdckxhreincnmzm` (`typeId`),
  CONSTRAINT `fk_mwrlwigfzckfvgohuzitiecyajoibtruyyla` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qgxsrfvxrckuapavzcdvfrdckxhreincnmzm` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iykppijzlhftbmgzrediexcwlgocruvmojse` (`sectionId`,`siteId`),
  KEY `idx_wizpaxmjpcnkanfprlctcchovxmumdgznwlq` (`siteId`),
  CONSTRAINT `fk_mnofgknzxuvzoxqwywycyeucfwpypfkqrkdt` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sjdwhsibezzorywjqjwuuydthvwwmjcauchn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) NOT NULL DEFAULT '',
  `sourceId` int DEFAULT NULL,
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) NOT NULL DEFAULT '',
  `sourceType` varchar(64) NOT NULL DEFAULT '',
  `typeId` int DEFAULT NULL,
  `sourceTemplate` varchar(500) DEFAULT '',
  `sourceSiteId` int DEFAULT NULL,
  `sourceAltSiteSettings` text,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text,
  `metaSiteVars` text,
  `metaSitemapVars` text,
  `metaContainers` text,
  `redirectsContainer` text,
  `frontendTemplatesContainer` text,
  `metaBundleSettings` text,
  PRIMARY KEY (`id`),
  KEY `idx_tikzyjlpsjlgiszzozdgxqrymgwdqaanngph` (`sourceBundleType`),
  KEY `idx_eutdsiybibtijudwdpuqsiibzjrxpcnjtabm` (`sourceId`),
  KEY `idx_qgmgyynrdphzpfccilfzjjuijwlpcwibyggw` (`sourceSiteId`),
  KEY `idx_tswfocichzznjkpmsjujcdaktjaoldagahjr` (`sourceHandle`),
  CONSTRAINT `fk_evxsruelgorkfwquafcyubocbebozopdexjd` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vqnpgdrnwzfhmdumunqoyddjsrgeetspunyo` (`uid`),
  KEY `idx_tfemtcroldvoidfalzvkedodrplcbgwfawsv` (`token`),
  KEY `idx_tyoeuczgenhqnwmgsnxbgvufdcibxzxvjndd` (`dateUpdated`),
  KEY `idx_dccehfgpazcksnnnczypogyjjdlkuvtnqmti` (`userId`),
  CONSTRAINT `fk_mhinunxkrzmngfavjaebytacmttfhecekjti` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_masllgwmtwhliligpcjehaehhbbgxekicozi` (`userId`,`message`),
  CONSTRAINT `fk_tuyxqzpilqoolixifkbxudmrwqfvycitfsic` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_npyftkzonjfqcdhdgndgtomnigravqkgluig` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_goepekiwadmxdfrmgwqiplmaimvbpqllnanq` (`dateDeleted`),
  KEY `idx_xchhipvndmezdddnzxpcnjgptstzmqgdzscp` (`handle`),
  KEY `idx_nblacuzhycrcgaestfzgnoicrlwhzkflbjwl` (`sortOrder`),
  KEY `fk_qrnxveddmjmqzhgkzdtdbclkfuvbwmppkdpu` (`groupId`),
  CONSTRAINT `fk_qrnxveddmjmqzhgkzdtdbclkfuvbwmppkdpu` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sprig_playgrounds`
--

DROP TABLE IF EXISTS `sprig_playgrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprig_playgrounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `component` text,
  `variables` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fsrsuukjjejwewqydohrafbqyqkcrvyetitm` (`structureId`,`elementId`),
  KEY `idx_xyixglhgkhucxnppavqqrynqpsqolphpjvai` (`root`),
  KEY `idx_vnfeytrecisjocueraozgrtfoooenffwavqr` (`lft`),
  KEY `idx_dnzdsyasfggcchacadyjsjhohicwezejlxeg` (`rgt`),
  KEY `idx_paoinzcmrmmqnjartxuvhluuzpcncjkmzxyc` (`level`),
  KEY `idx_apuiilkdukrcwcmeoczfvgjpwepyabiwiwkk` (`elementId`),
  CONSTRAINT `fk_fqzeymujujmoenwtlehzigpihpwygibtwffk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dodkwuyofgjhwwynkkeryixyhbmhuyfvwnlm` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ldblpmrrbcixpoptawfkyjddzbpxivgumuev` (`key`,`language`),
  KEY `idx_xwyknkptmsjqffnirjpbjbacyjosdaapewla` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vzmuvijhxmiljxvbqcrqnlyrmptevzddpioy` (`name`),
  KEY `idx_edyayqkvdivmmuudenqsvutqyckfytgwsacl` (`handle`),
  KEY `idx_gedtnkpkpirbrlxafuobhbhabwdwvcsqqmba` (`dateDeleted`),
  KEY `fk_snkndqtuhadgmjkszhllcopobishftazeozw` (`fieldLayoutId`),
  CONSTRAINT `fk_snkndqtuhadgmjkszhllcopobishftazeozw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fmqhszsdqtlgtqoqirevrxxpykeiyipwebbu` (`groupId`),
  CONSTRAINT `fk_ltiqlwhgwejdtgutxodpmdlrilbzzjhxkkvi` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nkdnfhwsundtrxkvylmvjnmoerxemwbxswdr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_chbzfmlcnbxqfchxumzbdbarvhhbkpbyjpaj` (`token`),
  KEY `idx_qofmzqipgbdbjvbjnkhjmulqldwfyboghikm` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hltqkqnlnbknaijnioxielcetffhytyhzrff` (`handle`),
  KEY `idx_wrmdsvinkbjelguonzcguwxpoyamngudknid` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tsyratqfkqberpbuezqdlfsdvzlplokmdkbo` (`groupId`,`userId`),
  KEY `idx_yojlrhmldqcnrsrbgoiokunfodmzmegxlvbp` (`userId`),
  CONSTRAINT `fk_ezkujogucugqsivsdqrmanmrtaabeffiqnyy` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ieimatvsjhxnuwiobkkhvycmzotcpwxxrvyg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wtqcbiubygnavqyuwnllqvlobrkhnwqacxwa` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ixfoyncigxdmpqdwuhyhrkkqojajotragzwa` (`permissionId`,`groupId`),
  KEY `idx_oxubvavzxwitunqlysdjxilnoedowoabivbp` (`groupId`),
  CONSTRAINT `fk_cqtatnqfqeyscgywzxcqwemiaghylvecvifn` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zfldqzcsqevlfkoyltctafwxockaagfppljh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_btsryrhmbxipecillqdlpxczeqtcxxipcprj` (`permissionId`,`userId`),
  KEY `idx_krvjnxlqgorsspzvjptmdfforlqgabymyiyq` (`userId`),
  CONSTRAINT `fk_euucsmvypcgqeuvjguglhlasxrvrnyzsmdxx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rjzcxzirtlfsbovntlybswzntkuhzbrtkvft` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_jcrzdblwwrsxlzrofnnpqlkqnovindrglkyv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fkkhxjubynqxqxidzblcsdpolqcxiyhrmate` (`active`),
  KEY `idx_obvngqouajvlpcoldvmalxhxseklpidcudum` (`locked`),
  KEY `idx_zgnfdqrkdhbbpawwcqnuaaojbwblgrfyhuby` (`pending`),
  KEY `idx_vqjfzmqfrstnyjxkgypuwvbjauzhwobjexxv` (`suspended`),
  KEY `idx_qywfcppprnldocwkiorumvgpaxgyypmcsnjb` (`verificationCode`),
  KEY `idx_oihybazzvgflemahnkodfjpxpnbnngstirnm` (`email`),
  KEY `idx_narganzadsvovxvtlqgpetrnsgbkokivnhpa` (`username`),
  KEY `fk_eibownctrinynaxzhaxhddudqoutrscyutsn` (`photoId`),
  CONSTRAINT `fk_eibownctrinynaxzhaxhddudqoutrscyutsn` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ekxsigmkukgjljhhmfknkllpdaryntzprskq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wxjxicemiczxelcbqohbeonxencalxjqvlrt` (`name`,`parentId`,`volumeId`),
  KEY `idx_xhukhzmqscyayvitikckyqjagruzrcvzdcwz` (`parentId`),
  KEY `idx_bvmfrookbajnggvvhpcjfsxhbrdhgoetardz` (`volumeId`),
  CONSTRAINT `fk_ixkvpmoulwnxpweidkumaqcsasqgmwxzawtg` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_juowgaddwcmqpfbppvdczxpizsuknfwepjun` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_upcfxzmjtsggvjxhrgukhsweimdedkfddeiv` (`name`),
  KEY `idx_tsugvrsfnciejzkxtjydoskdpwwjshvkqpxo` (`handle`),
  KEY `idx_pgbyhdlasvmqjjxobiskcovpdqdjijflalbl` (`fieldLayoutId`),
  KEY `idx_ghcajckbtbyrilrlgqkolgwdoaimdzyzhkcd` (`dateDeleted`),
  CONSTRAINT `fk_vmjsfbbbrcsfytakwjkholhtluofpltdfdrj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_cayehcwsmfdyixadjsnbabccqijcvmzykqhj` (`userId`),
  CONSTRAINT `fk_cayehcwsmfdyixadjsnbabccqijcvmzykqhj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_syzqisxrebitwdnihzgkbiwvqgktuimxlmcb` (`userId`),
  CONSTRAINT `fk_zugjprpslpclwmeirbukskeetbdimuyyufft` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'project'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 19:51:44
-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: project
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES
(3,1,'postDate','2024-04-30 03:46:39',0,1),
(3,1,'slug','2024-04-28 01:01:49',0,1),
(3,1,'title','2024-04-30 03:46:39',0,1),
(3,1,'uri','2024-04-28 01:01:49',0,1),
(4,1,'enabled','2024-04-28 01:02:09',0,1),
(4,1,'postDate','2024-04-28 01:08:29',0,1),
(59,1,'postDate','2024-04-28 02:28:57',0,1),
(60,1,'postDate','2024-04-28 02:28:57',0,1),
(61,1,'postDate','2024-04-28 02:29:37',0,1),
(69,1,'fieldLayoutId','2024-04-30 04:05:12',0,1),
(69,1,'typeId','2024-04-30 04:05:12',0,1),
(71,1,'fieldLayoutId','2024-04-30 03:57:26',0,1),
(71,1,'typeId','2024-04-30 03:57:26',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES
(3,1,10,'a83ec247-8188-46ad-8dd3-fb5acd4caec8','2024-04-28 02:28:57',0,1),
(59,1,9,'e8f4518e-9c6e-4b97-9b49-14f582079e52','2024-04-28 02:19:57',0,1),
(60,1,9,'e8f4518e-9c6e-4b97-9b49-14f582079e52','2024-04-28 02:24:30',0,1),
(61,1,6,'524c3914-caed-4fd7-a0cf-d6fb1c373632','2024-04-30 03:46:09',0,1),
(61,1,6,'ca82525a-4eef-4cca-b5bd-b9064fbd6487','2024-04-30 03:44:51',0,1),
(61,1,8,'ca49e688-1a34-4bed-b18d-57ec0e712abb','2024-04-30 03:44:51',0,1),
(61,1,9,'e8f4518e-9c6e-4b97-9b49-14f582079e52','2024-04-30 03:57:16',0,1),
(61,1,13,'32e05ff3-dd1a-4365-ba8f-08bd77df0e7f','2024-04-30 03:44:51',0,1),
(68,1,10,'a83ec247-8188-46ad-8dd3-fb5acd4caec8','2024-04-30 03:53:34',0,1),
(69,1,6,'10d999b9-f82d-4901-9c85-ae49b141c26b','2024-04-30 04:05:08',0,1),
(69,1,6,'ca82525a-4eef-4cca-b5bd-b9064fbd6487','2024-04-30 03:53:44',0,1),
(69,1,8,'ca49e688-1a34-4bed-b18d-57ec0e712abb','2024-04-30 03:53:50',0,1),
(69,1,9,'e8f4518e-9c6e-4b97-9b49-14f582079e52','2024-04-30 03:53:50',0,1),
(69,1,13,'32e05ff3-dd1a-4365-ba8f-08bd77df0e7f','2024-04-30 03:53:50',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES
(1,NULL,1,0,'First draft',NULL,0,NULL,1),
(2,NULL,1,0,'First draft',NULL,0,NULL,1),
(3,NULL,1,0,'First draft',NULL,0,NULL,1),
(4,NULL,1,0,'First draft',NULL,0,NULL,1),
(5,NULL,1,0,'First draft',NULL,0,NULL,1),
(6,NULL,1,0,'First draft',NULL,0,NULL,1),
(7,NULL,1,0,'First draft',NULL,0,NULL,1),
(8,NULL,1,0,'First draft',NULL,0,NULL,1),
(9,NULL,1,0,'First draft',NULL,0,NULL,0),
(16,NULL,1,0,'First draft',NULL,0,NULL,1),
(17,NULL,1,0,'First draft',NULL,0,NULL,1),
(18,NULL,1,0,'First draft',NULL,0,NULL,1),
(19,NULL,1,0,'First draft',NULL,0,NULL,1),
(20,NULL,1,0,'First draft',NULL,0,NULL,1),
(21,NULL,1,0,'First draft',NULL,0,NULL,1),
(22,NULL,1,0,'First draft',NULL,0,NULL,1),
(23,NULL,1,0,'First draft',NULL,0,NULL,1),
(27,NULL,1,0,'First draft',NULL,0,NULL,1),
(28,NULL,1,0,'First draft',NULL,0,NULL,1),
(33,NULL,1,0,'First draft',NULL,0,NULL,1),
(34,NULL,1,0,'First draft',NULL,0,NULL,1),
(35,NULL,1,0,'First draft',NULL,0,NULL,1),
(36,NULL,1,0,'First draft',NULL,0,NULL,1),
(37,NULL,1,0,'First draft',NULL,0,NULL,1),
(38,NULL,1,0,'First draft',NULL,0,NULL,1),
(39,NULL,1,0,'First draft',NULL,0,NULL,1),
(40,NULL,1,0,'First draft',NULL,0,NULL,1),
(43,NULL,1,0,'First draft',NULL,0,NULL,1),
(44,NULL,1,0,'First draft',NULL,0,NULL,1),
(45,NULL,1,0,'First draft',NULL,0,NULL,1),
(51,NULL,1,0,'First draft',NULL,0,NULL,1),
(73,3,1,1,'Draft 1','',1,NULL,1),
(74,NULL,1,0,'First draft',NULL,0,NULL,1),
(76,61,1,1,'Draft 1',NULL,1,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES
(3,1,1,NULL,'edit','2024-04-30 03:53:34'),
(3,1,1,NULL,'save','2024-04-30 03:46:39'),
(4,1,1,NULL,'save','2024-04-28 01:02:09'),
(59,1,1,NULL,'save','2024-04-28 02:19:57'),
(60,1,1,NULL,'save','2024-04-28 02:24:30'),
(61,1,1,NULL,'edit','2024-04-30 03:57:26'),
(61,1,1,NULL,'save','2024-04-30 03:57:16'),
(69,1,1,NULL,'save','2024-04-30 04:05:12');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-04-27 22:26:07','2024-04-27 22:26:07',NULL,NULL,NULL,'319c5485-28f5-48c3-8534-3f8a91980581'),
(2,NULL,9,NULL,1,'craft\\elements\\Entry',1,0,'2024-04-28 01:00:58','2024-04-28 01:00:58',NULL,NULL,NULL,'7aba54f9-6241-4c83-8116-40652844020e'),
(3,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-04-28 01:01:41','2024-04-30 03:46:39',NULL,NULL,NULL,'9f42660d-3f23-455b-a171-23fd0142f87a'),
(4,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-28 01:01:53','2024-04-28 01:08:29',NULL,NULL,NULL,'721a42b4-c90b-4e13-b6e1-a5774c2f7785'),
(59,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-28 02:19:46','2024-04-28 02:28:57',NULL,NULL,NULL,'e164bbc8-43d0-479f-be9d-84e8e6804cf5'),
(60,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-28 02:24:22','2024-04-28 02:28:57',NULL,NULL,NULL,'7c1a3f7e-c7b3-4e40-931f-135dc03b06a6'),
(61,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-28 02:29:04','2024-04-30 03:57:16',NULL,NULL,NULL,'d5f3acb3-71e6-4fdd-b7d3-965278bbacfa'),
(66,3,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-04-30 03:46:39','2024-04-30 03:46:39',NULL,NULL,NULL,'8cafa158-fcfa-45d6-8d8a-389ab374af10'),
(67,61,NULL,2,4,'craft\\elements\\Entry',1,0,'2024-04-30 03:46:30','2024-04-30 03:46:39',NULL,NULL,NULL,'f7959d2b-1257-478c-9e3e-186f1ad6aa9c'),
(68,3,73,NULL,1,'craft\\elements\\Entry',1,0,'2024-04-30 03:53:34','2024-04-30 03:53:34',NULL,NULL,NULL,'ed6ff5f4-63e3-4501-855d-3f13eaaef026'),
(69,NULL,74,NULL,5,'craft\\elements\\Entry',1,0,'2024-04-30 03:53:34','2024-04-30 04:05:12',NULL,NULL,NULL,'1d9c9d2f-8efb-4249-99fa-c174f7f0379b'),
(71,61,76,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-30 03:57:22','2024-04-30 03:57:26',NULL,NULL,NULL,'92992a13-6f23-4d02-a8c0-4852d6b681d1');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES
(61,3,1),
(61,68,1),
(67,66,1),
(69,68,2),
(71,3,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES
(1,1,1,NULL,NULL,NULL,NULL,1,'2024-04-27 22:26:07','2024-04-27 22:26:07','5b037fa0-2112-4cbe-8f14-5fca782c029a'),
(2,2,1,NULL,'__temp_tvcxxkceprbtfvgcysskjffjoezhrelfdhlz','__temp_tvcxxkceprbtfvgcysskjffjoezhrelfdhlz',NULL,1,'2024-04-28 01:00:58','2024-04-28 01:00:58','dda9eed1-0634-4bf5-8bba-8e408ff08d01'),
(3,3,1,'Home','__home__','__home__',NULL,1,'2024-04-28 01:01:41','2024-04-30 03:46:38','22b730db-0f43-42e7-8b53-3002a5800534'),
(4,4,1,NULL,'__temp_wdbpnswqcxpskonwdnynhvrykhntjkjgetmv',NULL,'{\"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{}\", \"value\": \"\", \"config\": \"_site/config/variant.{object.type.handle}.json\", \"element\": {\"id\": 4, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-28 01:01:53','2024-04-28 01:08:29','ef6130d9-3e6d-48ec-af04-f190b34dbf4e'),
(37,59,1,NULL,'__temp_yoadwltsnnhcpmtnrttkbfzsgxnhfzbtjrul',NULL,'{\"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{}\", \"value\": \"callout\", \"config\": \"_config/block.text.json\", \"element\": {\"id\": 59, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-28 02:19:46','2024-04-28 02:28:57','1d623009-8f7c-4187-8bcc-ea3146391323'),
(38,60,1,NULL,'__temp_mhdhtxaaladldkednrxojyceuwwwlgqbfyny',NULL,'{\"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{}\", \"value\": \"double\", \"config\": \"_config/block.text.json\", \"element\": {\"id\": 60, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-28 02:24:22','2024-04-28 02:28:57','1dfdc9ea-8326-4d72-8547-d2355224eddd'),
(39,61,1,NULL,'__temp_kluvpztofsfinpaznyqvwkkowakqlvkvcane',NULL,'{\"524c3914-caed-4fd7-a0cf-d6fb1c373632\": \"<h2>Neminem videbis ita laudatum, ut artifex callidus comparandarum voluptatum diceretur.</h2><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duo Reges: constructio interrete. Nescio quo modo praetervolavit oratio. <strong>Idemque diviserunt naturam hominis in animum et corpus.</strong></p><p>Erat enim Polemonis. Quamquam haec quidem praeposita recte et reiecta dicere licebit. <strong>Si longus, levis dictata sunt.</strong></p>\", \"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{\\\"textlayer\\\":\\\"default2col\\\"}\", \"value\": \"single\", \"config\": \"_config/block.variant.json\", \"element\": {\"id\": 70, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-28 02:29:04','2024-04-30 03:57:16','c48f9a87-3a17-4e0e-bebe-5979be66afb3'),
(44,66,1,'Home','__home__','__home__',NULL,1,'2024-04-30 03:46:39','2024-04-30 03:46:39','943fa6df-2c27-448a-985a-bba57369f584'),
(45,67,1,NULL,'__temp_kluvpztofsfinpaznyqvwkkowakqlvkvcane',NULL,'{\"524c3914-caed-4fd7-a0cf-d6fb1c373632\": \"<h2>Neminem videbis ita laudatum, ut artifex callidus comparandarum voluptatum diceretur.</h2><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duo Reges: constructio interrete. Nescio quo modo praetervolavit oratio. <strong>Idemque diviserunt naturam hominis in animum et corpus.</strong></p><p>Erat enim Polemonis. Quamquam haec quidem praeposita recte et reiecta dicere licebit. <strong>Si longus, levis dictata sunt.</strong></p>\", \"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{\\\"textlayer\\\":\\\"default2col\\\"}\", \"value\": \"single\", \"config\": \"_config/block.variant.json\", \"element\": {\"id\": 65, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-30 03:46:39','2024-04-30 03:46:39','65f50e72-fb39-4db8-9f26-edc6c1396242'),
(46,68,1,'Home','__home__','__home__',NULL,1,'2024-04-30 03:53:34','2024-04-30 03:53:34','54f90e11-3e21-4363-97dc-ea57491033b0'),
(47,69,1,NULL,'__temp_vxlzfanqcibpyqwxzenbdypwosvzkgxyvwlo',NULL,NULL,1,'2024-04-30 03:53:34','2024-04-30 04:05:12','ef723fe4-2891-4d5e-95e5-5e838de2a4a9'),
(49,71,1,NULL,'__temp_kluvpztofsfinpaznyqvwkkowakqlvkvcane',NULL,'{\"e8f4518e-9c6e-4b97-9b49-14f582079e52\": {\"json\": \"{}\", \"value\": \"\", \"config\": \"_config/block.variant.json\", \"element\": {\"id\": 71, \"type\": \"text\", \"class\": \"craft\\\\elements\\\\Entry\", \"field\": null, \"owner\": null, \"section\": null}}}',1,'2024-04-30 03:57:22','2024-04-30 03:57:26','c393a7ce-8321-4294-a19f-811abbd8e445');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES
(2,1,NULL,NULL,NULL,1,'2024-04-28 01:00:58',NULL,NULL,'2024-04-28 01:00:58','2024-04-28 01:00:58'),
(3,1,NULL,NULL,NULL,1,'2024-04-30 03:46:00',NULL,NULL,'2024-04-28 01:01:41','2024-04-30 03:46:39'),
(4,NULL,NULL,3,10,4,'2024-04-28 01:08:00',NULL,NULL,'2024-04-28 01:01:53','2024-04-28 01:08:29'),
(59,NULL,NULL,3,10,4,'2024-04-28 02:28:00',NULL,NULL,'2024-04-28 02:19:46','2024-04-28 02:28:57'),
(60,NULL,NULL,3,10,4,'2024-04-28 02:28:00',NULL,NULL,'2024-04-28 02:24:22','2024-04-28 02:28:57'),
(61,NULL,NULL,3,10,4,'2024-04-28 02:29:00',NULL,NULL,'2024-04-28 02:29:04','2024-04-28 02:29:37'),
(66,1,NULL,NULL,NULL,1,'2024-04-30 03:46:00',NULL,NULL,'2024-04-30 03:46:39','2024-04-30 03:46:39'),
(67,NULL,NULL,66,10,4,'2024-04-28 02:29:00',NULL,NULL,'2024-04-30 03:46:39','2024-04-30 03:46:39'),
(68,1,NULL,NULL,NULL,1,'2024-04-30 03:46:00',NULL,NULL,'2024-04-30 03:53:34','2024-04-30 03:53:34'),
(69,NULL,NULL,68,10,5,NULL,NULL,NULL,'2024-04-30 03:53:34','2024-04-30 04:05:12'),
(71,NULL,NULL,3,10,4,'2024-04-28 02:29:00',NULL,NULL,'2024-04-30 03:57:22','2024-04-30 03:57:26');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES
(2,1,1),
(3,1,1),
(66,1,1),
(68,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES
(1,1,'Fullpage','fullpage','shutters',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-27 22:36:00','2024-04-27 23:47:00',NULL,'99d1e742-e9ee-4468-8f52-06f9672d8f68'),
(2,2,'Sidebar','sidebar','sidebar-flip',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-27 22:36:24','2024-04-27 22:36:24',NULL,'a28f735a-3f02-4039-aaf6-a9c50e93122f'),
(3,3,'Image','image','image',NULL,0,'site',NULL,'',0,'site',NULL,0,'2024-04-27 22:37:56','2024-04-27 22:37:56',NULL,'4248eeb1-ca4d-476f-9998-7780ee611c74'),
(4,4,'Text','text','font-case',NULL,0,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:39:03','2024-04-27 23:48:15',NULL,'14dff90f-f8fc-444e-bc75-e51f72aa490d'),
(5,5,'Card Deck','carddeck','cards',NULL,0,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:39:40','2024-04-27 22:39:40',NULL,'96192f21-960f-489c-a380-96e4b51f2777'),
(6,6,'Media','media','tv-retro',NULL,0,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:40:26','2024-04-27 22:40:26',NULL,'b4783a60-e9ff-40a2-8e9e-159b24fad0a9'),
(7,7,'Component','componment','gear',NULL,0,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:41:03','2024-04-27 22:41:03',NULL,'faaa512e-f0ed-4151-97de-d73bdc9a4f5e'),
(8,8,'Fragment','fragment','puzzle-piece',NULL,0,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:41:45','2024-04-27 22:41:45',NULL,'06d15756-5b0e-4a06-a8db-0f2343d4b25f'),
(9,9,'Article','article','newspaper',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-27 22:42:14','2024-04-27 22:42:14',NULL,'80b8014d-fa4b-4271-9c59-73cd7c7c6d78'),
(10,10,'Bit','bit','bin-recycle',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:43:57','2024-04-27 22:43:57',NULL,'1eb561c2-313a-4ea5-9332-dd8effd8eb73'),
(11,11,'Dynamic Collection','dynamic','radar',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:45:33','2024-04-27 22:46:31',NULL,'21710874-0ba0-423c-82ec-7fd855abb982'),
(12,12,'Static Collection','static','list-radio',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:46:23','2024-04-27 22:46:23',NULL,'d7748b2a-ae79-4961-b103-a5aa758e39ab'),
(13,13,'RSS Feed','rss','rss',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:46:51','2024-04-27 22:46:51',NULL,'4b2a900b-f8d6-4b24-aee5-10ebc4051eb6'),
(14,14,'Sidebar Fragment','sidebarFragment','sidebar-flip',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:47:27','2024-04-27 22:47:27',NULL,'e56447b6-2288-47ba-89a8-e90f3970f3c7'),
(15,15,'Body Fragment','bodyFragment','shutters',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:48:26','2024-04-27 22:48:26',NULL,'ff76eb70-820e-4752-b138-daef62692e3f'),
(16,16,'Topic','topic','tags',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-27 22:49:08','2024-04-27 22:49:08',NULL,'bb561dd8-e748-4c68-9107-2ffd5db410d8'),
(17,17,'Private','private','user-secret',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-27 22:49:29','2024-04-27 22:49:29',NULL,'8b83b1c6-3917-4365-bc67-1f94599cbb08'),
(18,18,'Redirect','redirect','circle-arrow-right',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-27 22:49:53','2024-04-27 23:36:25',NULL,'0c3eb4bf-9fe7-422e-9947-289edfc00105'),
(19,19,'External Media','external','anchor',NULL,1,'site',NULL,'',0,'site',NULL,1,'2024-04-28 00:58:31','2024-04-28 00:58:31',NULL,'2508516d-3329-44ec-8518-04f2a29ca3f3');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"84e2ea5c-d6e3-44cf-ac8f-207b0fb8c88a\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ed397e10-39e7-447f-8f93-35eee2d0bc7f\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"a83ec247-8188-46ad-8dd3-fb5acd4caec8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"b4753be4-da84-4306-82e8-a9473ca5398f\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:36:00','2024-04-28 01:01:24',NULL,'c78854db-e1e0-457e-81b6-8637252ac031'),
(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"cb64d21d-e05c-4212-9f7b-f4379eba5346\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c9a2d0ff-e766-487a-b361-efe424d7beb8\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:36:24','2024-04-27 22:36:24',NULL,'ef80f310-e634-4441-bce7-2fb52df1c73d'),
(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"3383902d-5fd0-4eb5-b3cb-d5798e3a4aad\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b3fc6df1-5abe-4bcd-abc3-274ccb9da0a9\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"6ff2269f-1a61-4e6d-bcd0-dd05430035c9\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"10d999b9-f82d-4901-9c85-ae49b141c26b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"39adec54-ab28-4bf4-84a9-c01b591629d5\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"4b104ed0-4b08-424b-a744-f9bbf418fc2f\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:37:56','2024-04-30 03:58:01',NULL,'322a0f34-1814-4e8d-a8e7-6095f590bb43'),
(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"e021dbe8-88ec-4222-8d73-b314e36951e3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"de1772ac-b6f7-4eaa-b01f-2bf60292d95a\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"e8f4518e-9c6e-4b97-9b49-14f582079e52\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Block Variant\", \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"524c3914-caed-4fd7-a0cf-d6fb1c373632\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ca82525a-4eef-4cca-b5bd-b9064fbd6487\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": \"text2\", \"warning\": null, \"fieldUid\": \"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": {\"class\": \"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\", \"elementType\": \"craft\\\\elements\\\\Entry\", \"fieldContext\": \"global\", \"conditionRules\": [{\"uid\": \"4f3459b4-5e3f-4a00-890d-ec1f05fd1eef\", \"class\": \"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\", \"values\": [\"double\", \"reveal\"], \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"operator\": \"in\", \"layoutElementUid\": \"e8f4518e-9c6e-4b97-9b49-14f582079e52\"}]}}, {\"tip\": null, \"uid\": \"ca49e688-1a34-4bed-b18d-57ec0e712abb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"f3d34d10-7741-40ba-9fae-27d87f771b4d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": {\"class\": \"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\", \"elementType\": \"craft\\\\elements\\\\Entry\", \"fieldContext\": \"global\", \"conditionRules\": [{\"uid\": \"8f08bbe9-ac01-48e7-b587-a514fa476596\", \"class\": \"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\", \"values\": [\"callout\"], \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"operator\": \"in\", \"layoutElementUid\": \"e8f4518e-9c6e-4b97-9b49-14f582079e52\"}]}}, {\"tip\": null, \"uid\": \"32e05ff3-dd1a-4365-ba8f-08bd77df0e7f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": {\"class\": \"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\", \"elementType\": \"craft\\\\elements\\\\Entry\", \"fieldContext\": \"global\", \"conditionRules\": [{\"uid\": \"2f688f6d-7b6a-4f5f-a029-d840446ab912\", \"class\": \"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\", \"values\": [\"callout\"], \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"operator\": \"in\", \"layoutElementUid\": \"e8f4518e-9c6e-4b97-9b49-14f582079e52\"}]}}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:39:03','2024-04-30 03:44:16',NULL,'0f501c95-7567-4821-af33-c3872e0d6947'),
(5,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"46e6a9a3-4c05-449f-a4c2-492c41a78ebb\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a08012e6-9820-43a9-975d-70962daf1ffd\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:39:40','2024-04-27 22:39:40',NULL,'e71a5ed2-d4df-466a-b790-3b13aa7a2412'),
(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"408a25d4-998d-45d3-a875-c9038a60f203\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"8f8c6d9e-ccae-4474-b5a9-278798c778e9\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"36cfdd17-7a79-4f5a-b45f-46ded5796f39\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"31cc93a2-d38f-4943-b7c2-473b72eb69a1\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9526c500-4357-4b56-bef9-d88b8e65cf0b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"cd9863d6-70f6-4b2f-a1bb-98f5cf9bf95b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d8bf6768-4ff5-4727-ac20-12f8f0344542\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:40:26','2024-04-30 03:58:23',NULL,'0043a478-7bc5-4a6f-b717-de689da18143'),
(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2e11ef68-53fd-41c4-9396-c451aac88a1c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"fc3ada7c-ee60-4eb9-b55c-8c3bd067c9a8\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:41:03','2024-04-27 22:41:03',NULL,'b4475076-e702-46ac-ace4-e855d80c22be'),
(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"234a7ecd-45dc-43e5-b9d1-c5a2da00ad8a\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"0f564e2e-5e05-48a8-81c7-e6dc92f04c78\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:41:45','2024-04-27 22:41:45',NULL,'bf98dc04-1899-442c-baa2-2ad98f79e2dd'),
(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"3c3155c1-5a06-4af0-9133-a225c6fc3481\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"aedc1aa3-6210-41c6-ad77-bad9e5d8d7b2\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:42:14','2024-04-27 22:42:14',NULL,'b4b38964-c1af-4fb1-93cf-932474e3f431'),
(10,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"fc93ce85-8a48-4e3f-b1e4-636a7627734e\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"6867bcd7-af17-492f-a3a7-047f563b42f5\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:43:57','2024-04-27 22:43:57',NULL,'d5987dad-8fc6-4016-8a6f-f88bdcfc6149'),
(11,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"13018e87-c248-4884-8a35-03e84d892886\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"0ced76d2-45fd-4a95-98d0-d4aace59627a\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:45:33','2024-04-27 22:46:31',NULL,'645125bd-a9d4-4a89-9473-0b31f120ad4f'),
(12,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2ca4add9-ebec-491f-a9b6-b090360c7775\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c56a05a3-8a2a-4dcc-8672-dff79e54ad39\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:46:23','2024-04-27 22:46:23',NULL,'3a5fcba1-7080-4398-abf6-19311eb4d489'),
(13,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"6d0ed962-3faa-419f-a748-bcdbc5ff55a3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ffd4f14a-5ac2-4c78-a29f-5917a566ca3b\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:46:51','2024-04-27 22:46:51',NULL,'88a546fc-9281-41ec-95ed-067b8189e823'),
(14,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"5c86b900-b737-49bb-86a2-9562e978ff72\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"847014ed-76e3-4e9d-abe3-a0a34d2605ef\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:47:27','2024-04-27 22:47:27',NULL,'b43fa294-4ecf-4211-92f8-65e38074d0df'),
(15,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"7b6cfbc4-41c9-44e2-a7d6-41b9edf2286f\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"cb1b3b49-5006-4f9f-86ae-28fb646636c2\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:48:26','2024-04-27 22:48:26',NULL,'89296a1c-5559-43a3-8dea-a125ac30a48c'),
(16,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"cbf19f7c-2dd0-4513-bc6c-370b9bd8fe10\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b18e5684-7dcc-4721-8753-fd6cbe1a6d93\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:49:08','2024-04-27 22:49:08',NULL,'eef57681-5e0b-4580-b05a-72dea32206f5'),
(17,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b5571a90-5ef1-4d3c-a0f8-eaef63f89949\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a7bd709b-7584-4359-933e-2e1cc950bb04\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:49:29','2024-04-27 22:49:29',NULL,'a54bf7db-44fd-4a78-8262-cbb1b81d17ca'),
(18,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"c4b0958c-e3d0-4bb0-8c28-96f4eaaddad9\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a7407c6a-cf24-4101-b8e5-40db983e544c\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-27 22:49:53','2024-04-27 23:36:25',NULL,'f95c6ac3-8994-4936-919f-cf7d84dde245'),
(19,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2a8ab943-0b7a-407b-891a-366a3893b58a\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"99915c91-810f-4ec3-a1f3-3977fde78acf\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"34c14ce2-99c8-4ece-8121-448e83999375\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d554a8e7-e8ad-493b-aaa8-d611bf04b257\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"bcf1d856-765b-4e27-88f2-efd3169c577f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"f3d34d10-7741-40ba-9fae-27d87f771b4d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"34b55bb2-c8e5-4f26-9638-5217cbc85568\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 50, \"handle\": null, \"warning\": null, \"fieldUid\": \"4b104ed0-4b08-424b-a744-f9bbf418fc2f\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-28 00:58:31','2024-04-28 00:59:14',NULL,'b6162b48-2261-437e-a2de-07b767ec2e81');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES
(1,'Images','images','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":null,\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Choose\",\"showCardsInGrid\":true,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"cards\"}','2024-04-27 22:51:45','2024-04-27 22:51:45','4b104ed0-4b08-424b-a744-f9bbf418fc2f'),
(2,'Color','color','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":null}','2024-04-27 22:52:04','2024-04-27 22:52:04','581b9070-f50c-49a0-91c7-2921437ad0fb'),
(3,'Entries','entries','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":\"Choose\",\"showCardsInGrid\":true,\"showSiteMenu\":true,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"cards\"}','2024-04-27 22:52:32','2024-04-27 23:22:46','f240ce26-8d9d-4668-b18b-73371d5c5211'),
(4,'Media','media','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"audio\",\"compressed\",\"excel\",\"pdf\",\"powerpoint\",\"video\",\"word\"],\"branchLimit\":null,\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":null,\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Choose\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"cards\"}','2024-04-27 22:53:24','2024-04-27 22:53:24','d8bf6768-4ff5-4727-ac20-12f8f0344542'),
(5,'Icon','icon','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Icon',NULL,'2024-04-27 22:53:56','2024-04-27 23:22:58','b54aca1f-5631-4f76-a248-e953c4ada5bd'),
(6,'Text','text','global',NULL,NULL,1,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"ckeConfig\":\"ef0d77ed-a6ab-49db-afe4-2be38730d402\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-04-27 22:59:06','2024-04-27 22:59:14','7487ca3f-f51b-40e9-a538-40ab5b2c4a27'),
(8,'Summary','summary','global',NULL,NULL,1,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"ckeConfig\":\"ef0d77ed-a6ab-49db-afe4-2be38730d402\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":true,\"wordLimit\":null}','2024-04-27 23:00:21','2024-04-27 23:00:21','f3d34d10-7741-40ba-9fae-27d87f771b4d'),
(9,'Variant','variant','global',NULL,NULL,0,'none',NULL,'simplicateca\\selectplus\\fields\\SelectPlusField','{\"columnType\":null,\"configFile\":\"_config\\/block.variant.json\"}','2024-04-27 23:19:33','2024-04-30 03:30:56','31cc93a2-d38f-4943-b7c2-473b72eb69a1'),
(10,'Body Builder','bodyBuilder','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"minEntries\":null,\"maxEntries\":null,\"viewMode\":\"cards\",\"showCardsInGrid\":false,\"includeTableView\":false,\"defaultTableColumns\":[],\"pageSize\":50,\"createButtonLabel\":\"Add Block\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null,\"siteSettings\":{\"d34bee8e-bf22-451d-8339-a4342630833d\":[]},\"entryTypes\":[\"14dff90f-f8fc-444e-bc75-e51f72aa490d\",\"4248eeb1-ca4d-476f-9998-7780ee611c74\",\"96192f21-960f-489c-a380-96e4b51f2777\",\"b4783a60-e9ff-40a2-8e9e-159b24fad0a9\",\"faaa512e-f0ed-4151-97de-d73bdc9a4f5e\",\"06d15756-5b0e-4a06-a8db-0f2343d4b25f\"]}','2024-04-27 23:22:30','2024-04-28 02:24:19','b4753be4-da84-4306-82e8-a9473ca5398f'),
(11,'Website / Content URL','website','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Url','{\"maxLength\":255,\"types\":[\"url\"]}','2024-04-27 23:41:19','2024-04-27 23:41:19','d554a8e7-e8ad-493b-aaa8-d611bf04b257'),
(12,'Collections','collections','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":\"Choose\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:667ee826-8732-4bc8-8dbe-b7aefad82b15\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-04-27 23:41:52','2024-04-27 23:41:52','1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40'),
(13,'Bits','bits','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\TypeConditionRule\",\"uid\":\"eaf7301f-e1b9-40c7-9b79-eb4dbcd116af\",\"operator\":\"in\",\"values\":[\"1eb561c2-313a-4ea5-9332-dd8effd8eb73\"]}]},\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:685e625d-7180-40dc-a031-953f5f9a8cef\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-04-27 23:51:17','2024-04-27 23:51:17','ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES
(1,'5.1.0','5.0.0.20',0,'gdoijtkfdafp','3@vswxugjkxf','2024-04-27 22:26:07','2024-04-30 19:20:26','2ad83f05-316a-4b0e-8259-cf28816aafd6');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','808ad940-95b4-4fae-9aa5-b43d80068704'),
(2,'craft','m221101_115859_create_entries_authors_table','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','55b300fc-19d8-4e07-8e51-17a9d488e3e2'),
(3,'craft','m221107_112121_add_max_authors_to_sections','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','eac7ffb1-5d42-4871-839b-6070133260c2'),
(4,'craft','m221205_082005_translatable_asset_alt_text','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','e028b625-785d-454d-be8a-1def08e8e171'),
(5,'craft','m230314_110309_add_authenticator_table','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','5945c418-93f1-4825-97fe-5ea68815be08'),
(6,'craft','m230314_111234_add_webauthn_table','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','ac01f7aa-7e51-4581-84fe-5d570da29cae'),
(7,'craft','m230503_120303_add_recoverycodes_table','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','cfece296-bef6-467e-9ac2-94ae69e50402'),
(8,'craft','m230511_000000_field_layout_configs','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','1e86779c-f9d2-4f16-b4fd-f94964636d0c'),
(9,'craft','m230511_215903_content_refactor','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','d98da25e-4560-4f85-af47-83d875915641'),
(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','4f2b7634-20f1-4b30-85fa-e4d5a73eca95'),
(11,'craft','m230524_000001_entry_type_icons','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','6343e1bb-784f-417f-9d82-ed9e0b8c0fa5'),
(12,'craft','m230524_000002_entry_type_colors','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','7efb0930-4b0d-47db-8622-77e2ecf20721'),
(13,'craft','m230524_220029_global_entry_types','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','efb1ab89-5d36-4de9-a48e-def3a680b663'),
(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','4bb07bf7-c2b6-4040-8dc2-4762ca7fc995'),
(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','fb01a1ae-193d-4330-a024-a3beadc777bb'),
(16,'craft','m230616_173810_kill_field_groups','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','1a5430a7-3ab2-42a9-8830-de2c8e46b416'),
(17,'craft','m230616_183820_remove_field_name_limit','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','78f2bc1f-37a2-4136-8152-374db281fd30'),
(18,'craft','m230617_070415_entrify_matrix_blocks','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','391f96ee-3b95-4a75-aed6-fa8ce02c0219'),
(19,'craft','m230710_162700_element_activity','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','6ca5f8ab-e0f5-4a70-8b1b-a65c461abff7'),
(20,'craft','m230820_162023_fix_cache_id_type','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','659fa888-9289-43e7-819f-ccf766dddcfc'),
(21,'craft','m230826_094050_fix_session_id_type','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','c07765b1-8fba-47ea-930d-faf38f13e069'),
(22,'craft','m230904_190356_address_fields','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','a54ef9eb-4b45-4e93-bcbf-c1532205b8e2'),
(23,'craft','m230928_144045_add_subpath_to_volumes','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','0fdc7fd0-0f49-4a11-9b7e-17f614e787a0'),
(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','aada7056-3d7c-4116-bddc-a35efeae39f4'),
(25,'craft','m231213_030600_element_bulk_ops','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','8c812908-49d5-4015-a04b-c7e1697f65ac'),
(26,'craft','m240129_150719_sites_language_amend_length','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','2b4b6bb9-6eef-4e89-ab98-8a6e3914a754'),
(27,'craft','m240206_035135_convert_json_columns','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','ccc5dba8-6351-4f8b-ba49-a7d70191688b'),
(28,'craft','m240207_182452_address_line_3','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','c5269e8e-4312-48ae-831c-056cb5edfa76'),
(29,'craft','m240302_212719_solo_preview_targets','2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-27 22:26:08','126ef6f3-2f5a-4f6c-92f9-bf54af5d3517'),
(30,'plugin:ckeditor','Install','2024-04-27 22:58:06','2024-04-27 22:58:06','2024-04-27 22:58:06','e2feaef0-dcd9-4c85-b02e-df8abb885a18'),
(31,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-04-27 22:58:06','2024-04-27 22:58:06','2024-04-27 22:58:06','122b439f-c49d-47ca-aacd-df92d69864c0'),
(32,'plugin:sprig','Install','2024-04-30 03:54:58','2024-04-30 03:54:58','2024-04-30 03:54:58','2f682fba-2dab-4aec-9ad2-f87e83d6676d'),
(33,'plugin:seomatic','Install','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','391ac095-4c16-4944-ad3e-cb68a5390a3e'),
(34,'plugin:seomatic','m180314_002755_field_type','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','f40f6c61-4f96-4853-8298-9343fab2a52e'),
(35,'plugin:seomatic','m180314_002756_base_install','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','98bd7120-8f08-45e5-aaf4-259bdd57a9e0'),
(36,'plugin:seomatic','m180502_202319_remove_field_metabundles','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','7459c9aa-feec-43b8-b18d-f992b8afa7eb'),
(37,'plugin:seomatic','m180711_024947_commerce_products','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','a16f1f78-6187-4083-8a89-6e6c8664412d'),
(38,'plugin:seomatic','m190401_220828_longer_handles','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','d5b026ab-9a2d-4e01-8d8d-251c14cb40c6'),
(39,'plugin:seomatic','m190518_030221_calendar_events','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','8c8ad54a-0fa0-46df-92e2-01f82c7d9c00'),
(40,'plugin:seomatic','m200419_203444_add_type_id','2024-04-30 03:55:02','2024-04-30 03:55:02','2024-04-30 03:55:02','d3edf436-1903-4f5c-a2a2-49b17baa8569'),
(41,'plugin:seomatic','m210603_213100_add_gql_schema_components','2024-04-30 03:55:02','2024-04-30 03:55:02','2024-04-30 03:55:02','1cde4f57-bca4-497a-9b31-b0a5fd03db2c'),
(42,'plugin:seomatic','m210817_230853_announcement_v3_4','2024-04-30 03:55:02','2024-04-30 03:55:02','2024-04-30 03:55:02','72d4e47b-5a1b-4d23-b1c1-c26761b6811d'),
(43,'plugin:seomatic','m230601_184259_announcement_google_ua_deprecated','2024-04-30 03:55:02','2024-04-30 03:55:02','2024-04-30 03:55:02','3a78896d-09de-420b-8c62-5a62370228e8'),
(44,'plugin:navigation','Install','2024-04-30 03:55:09','2024-04-30 03:55:09','2024-04-30 03:55:09','ae6cd677-103a-47e4-81fe-7db6d17477d4'),
(45,'plugin:navigation','m231229_000000_content_refactor','2024-04-30 03:55:09','2024-04-30 03:55:09','2024-04-30 03:55:09','3b1b6462-f9f1-49ac-99ae-8f1a0fa7d390');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `navigation_navs`
--

LOCK TABLES `navigation_navs` WRITE;
/*!40000 ALTER TABLE `navigation_navs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `navigation_navs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `navigation_navs_sites`
--

LOCK TABLES `navigation_navs_sites` WRITE;
/*!40000 ALTER TABLE `navigation_navs_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `navigation_navs_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `navigation_nodes`
--

LOCK TABLES `navigation_nodes` WRITE;
/*!40000 ALTER TABLE `navigation_nodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `navigation_nodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES
(1,'ckeditor','4.0.4','3.0.0.0','2024-04-27 22:58:06','2024-04-27 22:58:06','2024-04-27 22:58:06','90e2e859-8b94-4f9e-ae16-ddd6ef542c72'),
(2,'selectplus','5.0.0-beta','1.0.0','2024-04-27 23:18:18','2024-04-27 23:18:18','2024-04-27 23:18:18','e6cf4cae-c294-47e7-a751-5590ed83a6e2'),
(3,'empty-coalesce','5.0.0','1.0.0','2024-04-28 01:00:51','2024-04-28 01:00:51','2024-04-28 01:00:51','a6b9f4f5-f62d-4ae9-b878-e1a57b4c46ef'),
(4,'retcon','3.0.0','1.0.0','2024-04-30 03:51:37','2024-04-30 03:51:37','2024-04-30 03:51:37','4ec474a6-8c5a-4de5-adc7-7d04a438a795'),
(5,'vite','5.0.0','1.0.0','2024-04-30 03:52:32','2024-04-30 03:52:32','2024-04-30 03:52:32','bebe3214-29f5-4f0e-824a-485b09a2691b'),
(6,'sprig','3.0.1','1.0.1','2024-04-30 03:54:58','2024-04-30 03:54:58','2024-04-30 03:54:58','7b9017bf-663d-4085-bfaa-d325396a154d'),
(7,'seomatic','5.0.2','3.0.12','2024-04-30 03:55:01','2024-04-30 03:55:01','2024-04-30 03:55:01','273fe4fb-8c1e-4d93-8a58-1380be8315ae'),
(8,'navigation','3.0.0-beta.3','2.1.0','2024-04-30 03:55:09','2024-04-30 03:55:09','2024-04-30 03:55:09','dae85f9e-5b73-407f-b4b5-ac0a460cad15');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.0','1'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.1','2'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.2','3'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.3','4'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.4','5'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.headingLevels.5','6'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.name','\"Simple\"'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.toolbar.0','\"heading\"'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.toolbar.1','\"|\"'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.toolbar.2','\"bold\"'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.toolbar.3','\"italic\"'),
('ckeditor.configs.ef0d77ed-a6ab-49db-afe4-2be38730d402.toolbar.4','\"link\"'),
('dateModified','1714449503'),
('elementSources.craft\\elements\\Entry.0.heading','\"Primary Content\"'),
('elementSources.craft\\elements\\Entry.0.type','\"heading\"'),
('elementSources.craft\\elements\\Entry.1.defaultSort.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.1.defaultSort.1','\"desc\"'),
('elementSources.craft\\elements\\Entry.1.disabled','false'),
('elementSources.craft\\elements\\Entry.1.key','\"section:b1ee8bc9-827b-4fec-943c-c6ff229adb59\"'),
('elementSources.craft\\elements\\Entry.1.tableAttributes.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.1.tableAttributes.1','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.1.tableAttributes.2','\"link\"'),
('elementSources.craft\\elements\\Entry.1.type','\"native\"'),
('elementSources.craft\\elements\\Entry.2.defaultSort.0','\"structure\"'),
('elementSources.craft\\elements\\Entry.2.defaultSort.1','\"asc\"'),
('elementSources.craft\\elements\\Entry.2.disabled','false'),
('elementSources.craft\\elements\\Entry.2.key','\"section:247cf34e-12cf-4324-b034-3209f48a18ff\"'),
('elementSources.craft\\elements\\Entry.2.tableAttributes.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.2.tableAttributes.1','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.2.tableAttributes.2','\"link\"'),
('elementSources.craft\\elements\\Entry.2.type','\"native\"'),
('elementSources.craft\\elements\\Entry.3.heading','\"Secondary Content\"'),
('elementSources.craft\\elements\\Entry.3.type','\"heading\"'),
('elementSources.craft\\elements\\Entry.4.key','\"section:4688dcb4-257f-4a94-b8b7-db234f63e0a9\"'),
('elementSources.craft\\elements\\Entry.4.type','\"native\"'),
('elementSources.craft\\elements\\Entry.5.heading','\"Meta Content\"'),
('elementSources.craft\\elements\\Entry.5.type','\"heading\"'),
('elementSources.craft\\elements\\Entry.6.defaultSort.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.6.defaultSort.1','\"desc\"'),
('elementSources.craft\\elements\\Entry.6.disabled','false'),
('elementSources.craft\\elements\\Entry.6.key','\"section:667ee826-8732-4bc8-8dbe-b7aefad82b15\"'),
('elementSources.craft\\elements\\Entry.6.tableAttributes.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.6.tableAttributes.1','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.6.tableAttributes.2','\"link\"'),
('elementSources.craft\\elements\\Entry.6.type','\"native\"'),
('elementSources.craft\\elements\\Entry.7.defaultSort.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.7.defaultSort.1','\"desc\"'),
('elementSources.craft\\elements\\Entry.7.disabled','false'),
('elementSources.craft\\elements\\Entry.7.key','\"section:685e625d-7180-40dc-a031-953f5f9a8cef\"'),
('elementSources.craft\\elements\\Entry.7.tableAttributes.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.7.tableAttributes.1','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.7.tableAttributes.2','\"link\"'),
('elementSources.craft\\elements\\Entry.7.type','\"native\"'),
('elementSources.craft\\elements\\Entry.8.defaultSort.0','\"structure\"'),
('elementSources.craft\\elements\\Entry.8.defaultSort.1','\"asc\"'),
('elementSources.craft\\elements\\Entry.8.disabled','false'),
('elementSources.craft\\elements\\Entry.8.key','\"section:83a6e4e2-3e52-435e-bcb4-ced4dc7e387e\"'),
('elementSources.craft\\elements\\Entry.8.tableAttributes.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.8.tableAttributes.1','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.8.tableAttributes.2','\"link\"'),
('elementSources.craft\\elements\\Entry.8.type','\"native\"'),
('elementSources.craft\\elements\\Entry.9.defaultSort.0','\"postDate\"'),
('elementSources.craft\\elements\\Entry.9.defaultSort.1','\"desc\"'),
('elementSources.craft\\elements\\Entry.9.disabled','true'),
('elementSources.craft\\elements\\Entry.9.key','\"*\"'),
('elementSources.craft\\elements\\Entry.9.tableAttributes.0','\"section\"'),
('elementSources.craft\\elements\\Entry.9.tableAttributes.1','\"postDate\"'),
('elementSources.craft\\elements\\Entry.9.tableAttributes.2','\"expiryDate\"'),
('elementSources.craft\\elements\\Entry.9.tableAttributes.3','\"link\"'),
('elementSources.craft\\elements\\Entry.9.type','\"native\"'),
('email.fromEmail','\"craft@example.com\"'),
('email.fromName','\"Craft CMS\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.color','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elementCondition','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.autocomplete','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.autocorrect','true'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.class','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.disabled','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.elementCondition','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.id','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.includeInCards','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.inputType','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.instructions','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.label','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.max','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.min','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.name','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.orientation','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.placeholder','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.readonly','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.requirable','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.size','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.step','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.tip','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.title','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.uid','\"0f564e2e-5e05-48a8-81c7-e6dc92f04c78\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.userCondition','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.warning','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.elements.0.width','100'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.name','\"Content\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.uid','\"234a7ecd-45dc-43e5-b9d1-c5a2da00ad8a\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.fieldLayouts.bf98dc04-1899-442c-baa2-2ad98f79e2dd.tabs.0.userCondition','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.handle','\"fragment\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.hasTitleField','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.icon','\"puzzle-piece\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.name','\"Fragment\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.showSlugField','false'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.showStatusField','true'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.slugTranslationKeyFormat','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.slugTranslationMethod','\"site\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.titleFormat','\"\"'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.titleTranslationKeyFormat','null'),
('entryTypes.06d15756-5b0e-4a06-a8db-0f2343d4b25f.titleTranslationMethod','\"site\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.color','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elementCondition','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.autocomplete','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.autocorrect','true'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.class','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.disabled','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.elementCondition','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.id','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.includeInCards','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.inputType','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.instructions','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.label','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.max','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.min','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.name','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.orientation','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.placeholder','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.readonly','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.requirable','false'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.size','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.step','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.tip','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.title','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.uid','\"a7407c6a-cf24-4101-b8e5-40db983e544c\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.userCondition','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.warning','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.elements.0.width','100'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.name','\"Content\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.uid','\"c4b0958c-e3d0-4bb0-8c28-96f4eaaddad9\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.fieldLayouts.f95c6ac3-8994-4936-919f-cf7d84dde245.tabs.0.userCondition','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.handle','\"redirect\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.hasTitleField','true'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.icon','\"circle-arrow-right\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.name','\"Redirect\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.showSlugField','true'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.showStatusField','true'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.slugTranslationKeyFormat','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.slugTranslationMethod','\"site\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.titleFormat','\"\"'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.titleTranslationKeyFormat','null'),
('entryTypes.0c3eb4bf-9fe7-422e-9947-289edfc00105.titleTranslationMethod','\"site\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.color','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elementCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.autocomplete','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.autocorrect','true'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.class','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.disabled','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.elementCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.id','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.inputType','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.label','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.max','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.min','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.name','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.orientation','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.placeholder','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.readonly','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.requirable','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.size','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.step','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.title','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.uid','\"de1772ac-b6f7-4eaa-b01f-2bf60292d95a\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.0.width','100'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.elementCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.handle','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.label','\"Block Variant\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.required','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.uid','\"e8f4518e-9c6e-4b97-9b49-14f582079e52\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.1.width','100'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.elementCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.fieldUid','\"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.handle','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.label','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.required','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.uid','\"524c3914-caed-4fd7-a0cf-d6fb1c373632\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.2.width','100'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.class','\"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.layoutElementUid','\"e8f4518e-9c6e-4b97-9b49-14f582079e52\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.operator','\"in\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.uid','\"4f3459b4-5e3f-4a00-890d-ec1f05fd1eef\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.values.0','\"double\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.conditionRules.0.values.1','\"reveal\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.elementCondition.fieldContext','\"global\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.fieldUid','\"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.handle','\"text2\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.label','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.required','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.uid','\"ca82525a-4eef-4cca-b5bd-b9064fbd6487\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.3.width','100'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.class','\"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.layoutElementUid','\"e8f4518e-9c6e-4b97-9b49-14f582079e52\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.operator','\"in\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.uid','\"8f08bbe9-ac01-48e7-b587-a514fa476596\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.conditionRules.0.values.0','\"callout\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.elementCondition.fieldContext','\"global\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.fieldUid','\"f3d34d10-7741-40ba-9fae-27d87f771b4d\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.handle','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.label','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.required','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.uid','\"ca49e688-1a34-4bed-b18d-57ec0e712abb\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.4.width','50'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.class','\"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusConditionRule\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.layoutElementUid','\"e8f4518e-9c6e-4b97-9b49-14f582079e52\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.operator','\"in\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.uid','\"2f688f6d-7b6a-4f5f-a029-d840446ab912\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.conditionRules.0.values.0','\"callout\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.elementCondition.fieldContext','\"global\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.fieldUid','\"ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.handle','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.includeInCards','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.instructions','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.label','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.providesThumbs','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.required','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.tip','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.uid','\"32e05ff3-dd1a-4365-ba8f-08bd77df0e7f\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.warning','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.elements.5.width','50'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.name','\"Content\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.uid','\"e021dbe8-88ec-4222-8d73-b314e36951e3\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.fieldLayouts.0f501c95-7567-4821-af33-c3872e0d6947.tabs.0.userCondition','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.handle','\"text\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.hasTitleField','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.icon','\"font-case\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.name','\"Text\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.showSlugField','false'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.showStatusField','true'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.slugTranslationKeyFormat','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.slugTranslationMethod','\"site\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.titleFormat','\"\"'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.titleTranslationKeyFormat','null'),
('entryTypes.14dff90f-f8fc-444e-bc75-e51f72aa490d.titleTranslationMethod','\"site\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.color','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elementCondition','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.autocomplete','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.autocorrect','true'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.class','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.disabled','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.elementCondition','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.id','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.includeInCards','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.inputType','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.instructions','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.label','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.max','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.min','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.name','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.orientation','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.placeholder','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.readonly','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.requirable','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.size','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.step','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.tip','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.title','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.uid','\"6867bcd7-af17-492f-a3a7-047f563b42f5\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.userCondition','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.warning','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.elements.0.width','100'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.name','\"Content\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.uid','\"fc93ce85-8a48-4e3f-b1e4-636a7627734e\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.fieldLayouts.d5987dad-8fc6-4016-8a6f-f88bdcfc6149.tabs.0.userCondition','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.handle','\"bit\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.hasTitleField','true'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.icon','\"bin-recycle\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.name','\"Bit\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.showSlugField','false'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.showStatusField','true'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.slugTranslationKeyFormat','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.slugTranslationMethod','\"site\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.titleFormat','\"\"'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.titleTranslationKeyFormat','null'),
('entryTypes.1eb561c2-313a-4ea5-9332-dd8effd8eb73.titleTranslationMethod','\"site\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.color','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elementCondition','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.autocomplete','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.autocorrect','true'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.class','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.disabled','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.elementCondition','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.id','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.includeInCards','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.inputType','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.instructions','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.label','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.max','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.min','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.name','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.orientation','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.placeholder','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.readonly','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.requirable','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.size','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.step','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.tip','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.title','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.uid','\"0ced76d2-45fd-4a95-98d0-d4aace59627a\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.userCondition','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.warning','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.elements.0.width','100'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.name','\"Content\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.uid','\"13018e87-c248-4884-8a35-03e84d892886\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.fieldLayouts.645125bd-a9d4-4a89-9473-0b31f120ad4f.tabs.0.userCondition','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.handle','\"dynamic\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.hasTitleField','true'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.icon','\"radar\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.name','\"Dynamic Collection\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.showSlugField','false'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.showStatusField','true'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.slugTranslationKeyFormat','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.slugTranslationMethod','\"site\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.titleFormat','\"\"'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.titleTranslationKeyFormat','null'),
('entryTypes.21710874-0ba0-423c-82ec-7fd855abb982.titleTranslationMethod','\"site\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.color','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elementCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.autocomplete','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.autocorrect','true'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.class','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.disabled','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.elementCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.id','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.includeInCards','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.inputType','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.instructions','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.label','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.max','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.min','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.name','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.orientation','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.placeholder','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.readonly','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.requirable','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.size','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.step','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.tip','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.title','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.uid','\"99915c91-810f-4ec3-a1f3-3977fde78acf\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.userCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.warning','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.0.width','100'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.elementCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.fieldUid','\"d554a8e7-e8ad-493b-aaa8-d611bf04b257\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.handle','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.includeInCards','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.instructions','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.label','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.required','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.tip','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.uid','\"34c14ce2-99c8-4ece-8121-448e83999375\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.userCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.warning','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.1.width','100'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.elementCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.fieldUid','\"f3d34d10-7741-40ba-9fae-27d87f771b4d\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.handle','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.includeInCards','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.instructions','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.label','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.providesThumbs','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.required','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.tip','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.uid','\"bcf1d856-765b-4e27-88f2-efd3169c577f\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.userCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.warning','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.2.width','50'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.elementCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.fieldUid','\"4b104ed0-4b08-424b-a744-f9bbf418fc2f\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.handle','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.includeInCards','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.instructions','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.label','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.providesThumbs','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.required','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.tip','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.uid','\"34b55bb2-c8e5-4f26-9638-5217cbc85568\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.userCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.warning','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.elements.3.width','50'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.name','\"Content\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.uid','\"2a8ab943-0b7a-407b-891a-366a3893b58a\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.fieldLayouts.b6162b48-2261-437e-a2de-07b767ec2e81.tabs.0.userCondition','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.handle','\"external\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.hasTitleField','true'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.icon','\"anchor\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.name','\"External Media\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.showSlugField','false'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.showStatusField','true'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.slugTranslationKeyFormat','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.slugTranslationMethod','\"site\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.titleFormat','\"\"'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.titleTranslationKeyFormat','null'),
('entryTypes.2508516d-3329-44ec-8518-04f2a29ca3f3.titleTranslationMethod','\"site\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.color','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elementCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.autocomplete','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.autocorrect','true'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.class','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.disabled','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.elementCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.id','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.includeInCards','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.inputType','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.instructions','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.label','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.max','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.min','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.name','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.orientation','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.placeholder','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.readonly','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.requirable','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.size','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.step','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.tip','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.title','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.uid','\"b3fc6df1-5abe-4bcd-abc3-274ccb9da0a9\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.userCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.warning','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.0.width','100'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.elementCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.handle','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.includeInCards','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.instructions','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.label','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.required','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.tip','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.uid','\"6ff2269f-1a61-4e6d-bcd0-dd05430035c9\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.userCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.warning','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.1.width','100'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.elementCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.fieldUid','\"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.handle','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.includeInCards','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.instructions','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.label','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.providesThumbs','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.required','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.tip','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.uid','\"10d999b9-f82d-4901-9c85-ae49b141c26b\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.userCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.warning','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.2.width','100'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.elementCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.fieldUid','\"4b104ed0-4b08-424b-a744-f9bbf418fc2f\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.handle','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.includeInCards','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.instructions','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.label','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.providesThumbs','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.required','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.tip','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.uid','\"39adec54-ab28-4bf4-84a9-c01b591629d5\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.userCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.warning','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.elements.3.width','100'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.name','\"Content\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.uid','\"3383902d-5fd0-4eb5-b3cb-d5798e3a4aad\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.fieldLayouts.322a0f34-1814-4e8d-a8e7-6095f590bb43.tabs.0.userCondition','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.handle','\"image\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.hasTitleField','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.icon','\"image\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.name','\"Image\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.showSlugField','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.showStatusField','false'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.slugTranslationKeyFormat','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.slugTranslationMethod','\"site\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.titleFormat','\"\"'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.titleTranslationKeyFormat','null'),
('entryTypes.4248eeb1-ca4d-476f-9998-7780ee611c74.titleTranslationMethod','\"site\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.color','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elementCondition','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.autocomplete','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.autocorrect','true'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.class','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.disabled','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.elementCondition','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.id','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.includeInCards','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.inputType','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.instructions','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.label','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.max','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.min','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.name','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.orientation','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.placeholder','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.readonly','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.requirable','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.size','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.step','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.tip','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.title','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.uid','\"ffd4f14a-5ac2-4c78-a29f-5917a566ca3b\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.userCondition','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.warning','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.elements.0.width','100'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.name','\"Content\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.uid','\"6d0ed962-3faa-419f-a748-bcdbc5ff55a3\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.fieldLayouts.88a546fc-9281-41ec-95ed-067b8189e823.tabs.0.userCondition','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.handle','\"rss\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.hasTitleField','true'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.icon','\"rss\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.name','\"RSS Feed\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.showSlugField','false'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.showStatusField','true'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.slugTranslationKeyFormat','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.slugTranslationMethod','\"site\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.titleFormat','\"\"'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.titleTranslationKeyFormat','null'),
('entryTypes.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6.titleTranslationMethod','\"site\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.color','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elementCondition','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.autocomplete','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.autocorrect','true'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.class','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.disabled','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.elementCondition','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.id','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.includeInCards','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.inputType','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.instructions','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.label','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.max','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.min','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.name','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.orientation','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.placeholder','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.readonly','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.requirable','false'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.size','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.step','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.tip','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.title','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.uid','\"aedc1aa3-6210-41c6-ad77-bad9e5d8d7b2\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.userCondition','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.warning','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.elements.0.width','100'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.name','\"Content\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.uid','\"3c3155c1-5a06-4af0-9133-a225c6fc3481\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.fieldLayouts.b4b38964-c1af-4fb1-93cf-932474e3f431.tabs.0.userCondition','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.handle','\"article\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.hasTitleField','true'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.icon','\"newspaper\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.name','\"Article\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.showSlugField','true'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.showStatusField','true'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.slugTranslationKeyFormat','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.slugTranslationMethod','\"site\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.titleFormat','\"\"'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.titleTranslationKeyFormat','null'),
('entryTypes.80b8014d-fa4b-4271-9c59-73cd7c7c6d78.titleTranslationMethod','\"site\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.color','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elementCondition','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.autocomplete','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.autocorrect','true'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.class','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.disabled','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.elementCondition','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.id','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.includeInCards','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.inputType','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.instructions','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.label','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.max','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.min','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.name','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.orientation','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.placeholder','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.readonly','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.requirable','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.size','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.step','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.tip','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.title','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.uid','\"a7bd709b-7584-4359-933e-2e1cc950bb04\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.userCondition','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.warning','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.elements.0.width','100'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.name','\"Content\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.uid','\"b5571a90-5ef1-4d3c-a0f8-eaef63f89949\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.fieldLayouts.a54bf7db-44fd-4a78-8262-cbb1b81d17ca.tabs.0.userCondition','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.handle','\"private\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.hasTitleField','true'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.icon','\"user-secret\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.name','\"Private\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.showSlugField','false'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.showStatusField','true'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.slugTranslationKeyFormat','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.slugTranslationMethod','\"site\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.titleFormat','\"\"'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.titleTranslationKeyFormat','null'),
('entryTypes.8b83b1c6-3917-4365-bc67-1f94599cbb08.titleTranslationMethod','\"site\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.color','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elementCondition','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.autocomplete','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.autocorrect','true'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.class','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.disabled','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.elementCondition','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.id','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.includeInCards','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.inputType','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.instructions','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.label','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.max','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.min','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.name','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.orientation','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.placeholder','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.readonly','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.requirable','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.size','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.step','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.tip','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.title','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.uid','\"a08012e6-9820-43a9-975d-70962daf1ffd\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.userCondition','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.warning','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.elements.0.width','100'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.name','\"Content\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.uid','\"46e6a9a3-4c05-449f-a4c2-492c41a78ebb\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.fieldLayouts.e71a5ed2-d4df-466a-b790-3b13aa7a2412.tabs.0.userCondition','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.handle','\"carddeck\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.hasTitleField','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.icon','\"cards\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.name','\"Card Deck\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.showSlugField','false'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.showStatusField','true'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.slugTranslationKeyFormat','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.slugTranslationMethod','\"site\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.titleFormat','\"\"'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.titleTranslationKeyFormat','null'),
('entryTypes.96192f21-960f-489c-a380-96e4b51f2777.titleTranslationMethod','\"site\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.color','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elementCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.autocomplete','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.autocorrect','true'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.class','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.disabled','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.elementCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.id','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.includeInCards','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.inputType','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.instructions','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.label','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.max','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.min','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.name','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.orientation','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.placeholder','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.readonly','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.requirable','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.size','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.step','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.tip','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.title','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.uid','\"ed397e10-39e7-447f-8f93-35eee2d0bc7f\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.userCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.warning','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.0.width','100'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.elementCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.fieldUid','\"b4753be4-da84-4306-82e8-a9473ca5398f\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.handle','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.includeInCards','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.instructions','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.label','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.required','false'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.tip','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.uid','\"a83ec247-8188-46ad-8dd3-fb5acd4caec8\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.userCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.warning','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.elements.1.width','100'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.name','\"Content\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.uid','\"84e2ea5c-d6e3-44cf-ac8f-207b0fb8c88a\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.fieldLayouts.c78854db-e1e0-457e-81b6-8637252ac031.tabs.0.userCondition','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.handle','\"fullpage\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.hasTitleField','true'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.icon','\"shutters\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.name','\"Fullpage\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.showSlugField','true'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.showStatusField','true'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.slugTranslationKeyFormat','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.slugTranslationMethod','\"site\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.titleFormat','\"\"'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.titleTranslationKeyFormat','null'),
('entryTypes.99d1e742-e9ee-4468-8f52-06f9672d8f68.titleTranslationMethod','\"site\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.color','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elementCondition','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.autocomplete','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.autocorrect','true'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.class','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.disabled','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.elementCondition','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.id','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.includeInCards','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.inputType','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.instructions','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.label','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.max','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.min','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.name','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.orientation','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.placeholder','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.readonly','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.requirable','false'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.size','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.step','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.tip','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.title','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.uid','\"c9a2d0ff-e766-487a-b361-efe424d7beb8\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.userCondition','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.warning','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.elements.0.width','100'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.name','\"Content\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.uid','\"cb64d21d-e05c-4212-9f7b-f4379eba5346\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.fieldLayouts.ef80f310-e634-4441-bce7-2fb52df1c73d.tabs.0.userCondition','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.handle','\"sidebar\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.hasTitleField','true'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.icon','\"sidebar-flip\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.name','\"Sidebar\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.showSlugField','true'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.showStatusField','true'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.slugTranslationKeyFormat','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.slugTranslationMethod','\"site\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.titleFormat','\"\"'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.titleTranslationKeyFormat','null'),
('entryTypes.a28f735a-3f02-4039-aaf6-a9c50e93122f.titleTranslationMethod','\"site\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.color','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elementCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.autocomplete','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.autocorrect','true'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.class','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.disabled','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.elementCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.id','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.includeInCards','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.inputType','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.instructions','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.label','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.max','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.min','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.name','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.orientation','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.placeholder','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.readonly','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.requirable','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.size','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.step','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.tip','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.title','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.uid','\"8f8c6d9e-ccae-4474-b5a9-278798c778e9\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.userCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.warning','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.0.width','100'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.elementCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.fieldUid','\"31cc93a2-d38f-4943-b7c2-473b72eb69a1\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.handle','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.includeInCards','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.instructions','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.label','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.required','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.tip','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.uid','\"36cfdd17-7a79-4f5a-b45f-46ded5796f39\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.userCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.warning','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.1.width','100'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.elementCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.fieldUid','\"7487ca3f-f51b-40e9-a538-40ab5b2c4a27\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.handle','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.includeInCards','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.instructions','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.label','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.providesThumbs','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.required','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.tip','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.uid','\"9526c500-4357-4b56-bef9-d88b8e65cf0b\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.userCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.warning','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.2.width','100'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.elementCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.fieldUid','\"d8bf6768-4ff5-4727-ac20-12f8f0344542\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.handle','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.includeInCards','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.instructions','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.label','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.providesThumbs','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.required','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.tip','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.uid','\"cd9863d6-70f6-4b2f-a1bb-98f5cf9bf95b\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.userCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.warning','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.elements.3.width','100'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.name','\"Content\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.uid','\"408a25d4-998d-45d3-a875-c9038a60f203\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.fieldLayouts.0043a478-7bc5-4a6f-b717-de689da18143.tabs.0.userCondition','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.handle','\"media\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.hasTitleField','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.icon','\"tv-retro\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.name','\"Media\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.showSlugField','false'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.showStatusField','true'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.slugTranslationKeyFormat','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.slugTranslationMethod','\"site\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.titleFormat','\"\"'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.titleTranslationKeyFormat','null'),
('entryTypes.b4783a60-e9ff-40a2-8e9e-159b24fad0a9.titleTranslationMethod','\"site\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.color','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elementCondition','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.autocomplete','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.autocorrect','true'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.class','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.disabled','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.elementCondition','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.id','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.includeInCards','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.inputType','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.instructions','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.label','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.max','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.min','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.name','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.orientation','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.placeholder','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.readonly','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.requirable','false'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.size','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.step','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.tip','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.title','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.uid','\"b18e5684-7dcc-4721-8753-fd6cbe1a6d93\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.userCondition','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.warning','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.elements.0.width','100'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.name','\"Content\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.uid','\"cbf19f7c-2dd0-4513-bc6c-370b9bd8fe10\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.fieldLayouts.eef57681-5e0b-4580-b05a-72dea32206f5.tabs.0.userCondition','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.handle','\"topic\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.hasTitleField','true'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.icon','\"tags\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.name','\"Topic\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.showSlugField','true'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.showStatusField','true'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.slugTranslationKeyFormat','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.slugTranslationMethod','\"site\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.titleFormat','\"\"'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.titleTranslationKeyFormat','null'),
('entryTypes.bb561dd8-e748-4c68-9107-2ffd5db410d8.titleTranslationMethod','\"site\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.color','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elementCondition','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.autocomplete','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.autocorrect','true'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.class','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.disabled','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.elementCondition','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.id','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.includeInCards','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.inputType','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.instructions','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.label','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.max','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.min','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.name','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.orientation','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.placeholder','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.readonly','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.requirable','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.size','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.step','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.tip','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.title','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.uid','\"c56a05a3-8a2a-4dcc-8672-dff79e54ad39\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.userCondition','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.warning','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.elements.0.width','100'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.name','\"Content\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.uid','\"2ca4add9-ebec-491f-a9b6-b090360c7775\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.fieldLayouts.3a5fcba1-7080-4398-abf6-19311eb4d489.tabs.0.userCondition','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.handle','\"static\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.hasTitleField','true'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.icon','\"list-radio\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.name','\"Static Collection\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.showSlugField','false'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.showStatusField','true'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.slugTranslationKeyFormat','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.slugTranslationMethod','\"site\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.titleFormat','\"\"'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.titleTranslationKeyFormat','null'),
('entryTypes.d7748b2a-ae79-4961-b103-a5aa758e39ab.titleTranslationMethod','\"site\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.color','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elementCondition','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.autocomplete','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.autocorrect','true'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.class','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.disabled','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.elementCondition','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.id','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.includeInCards','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.inputType','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.instructions','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.label','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.max','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.min','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.name','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.orientation','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.placeholder','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.readonly','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.requirable','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.size','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.step','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.tip','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.title','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.uid','\"847014ed-76e3-4e9d-abe3-a0a34d2605ef\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.userCondition','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.warning','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.elements.0.width','100'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.name','\"Content\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.uid','\"5c86b900-b737-49bb-86a2-9562e978ff72\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.fieldLayouts.b43fa294-4ecf-4211-92f8-65e38074d0df.tabs.0.userCondition','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.handle','\"sidebarFragment\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.hasTitleField','true'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.icon','\"sidebar-flip\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.name','\"Sidebar Fragment\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.showSlugField','false'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.showStatusField','true'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.slugTranslationKeyFormat','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.slugTranslationMethod','\"site\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.titleFormat','\"\"'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.titleTranslationKeyFormat','null'),
('entryTypes.e56447b6-2288-47ba-89a8-e90f3970f3c7.titleTranslationMethod','\"site\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.color','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elementCondition','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.autocomplete','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.autocorrect','true'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.class','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.disabled','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.elementCondition','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.id','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.includeInCards','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.inputType','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.instructions','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.label','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.max','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.min','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.name','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.orientation','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.placeholder','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.readonly','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.requirable','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.size','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.step','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.tip','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.title','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.uid','\"fc3ada7c-ee60-4eb9-b55c-8c3bd067c9a8\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.userCondition','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.warning','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.elements.0.width','100'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.name','\"Content\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.uid','\"2e11ef68-53fd-41c4-9396-c451aac88a1c\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.fieldLayouts.b4475076-e702-46ac-ace4-e855d80c22be.tabs.0.userCondition','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.handle','\"componment\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.hasTitleField','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.icon','\"gear\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.name','\"Component\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.showSlugField','false'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.showStatusField','true'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.slugTranslationKeyFormat','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.slugTranslationMethod','\"site\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.titleFormat','\"\"'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.titleTranslationKeyFormat','null'),
('entryTypes.faaa512e-f0ed-4151-97de-d73bdc9a4f5e.titleTranslationMethod','\"site\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.color','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elementCondition','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.autocomplete','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.autocorrect','true'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.class','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.disabled','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.elementCondition','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.id','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.includeInCards','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.inputType','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.instructions','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.label','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.max','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.min','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.name','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.orientation','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.placeholder','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.readonly','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.requirable','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.size','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.step','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.tip','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.title','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.uid','\"cb1b3b49-5006-4f9f-86ae-28fb646636c2\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.userCondition','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.warning','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.elements.0.width','100'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.name','\"Content\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.uid','\"7b6cfbc4-41c9-44e2-a7d6-41b9edf2286f\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.fieldLayouts.89296a1c-5559-43a3-8dea-a125ac30a48c.tabs.0.userCondition','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.handle','\"bodyFragment\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.hasTitleField','true'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.icon','\"shutters\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.name','\"Body Fragment\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.showSlugField','false'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.showStatusField','true'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.slugTranslationKeyFormat','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.slugTranslationMethod','\"site\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.titleFormat','\"\"'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.titleTranslationKeyFormat','null'),
('entryTypes.ff76eb70-820e-4752-b138-daef62692e3f.titleTranslationMethod','\"site\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.columnSuffix','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.handle','\"collections\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.instructions','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.name','\"Collections\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.searchable','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.allowSelfRelations','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.branchLimit','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.localizeRelations','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.maintainHierarchy','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.maxRelations','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.minRelations','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.selectionLabel','\"Choose\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.showCardsInGrid','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.showSiteMenu','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.sources.0','\"section:667ee826-8732-4bc8-8dbe-b7aefad82b15\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.targetSiteId','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.validateRelatedElements','false'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.settings.viewMode','\"list\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.translationKeyFormat','null'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.translationMethod','\"site\"'),
('fields.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40.type','\"craft\\\\fields\\\\Entries\"'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.columnSuffix','null'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.handle','\"variant\"'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.instructions','null'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.name','\"Variant\"'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.searchable','false'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.settings.columnType','null'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.settings.configFile','\"_config/block.variant.json\"'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.translationKeyFormat','null'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.translationMethod','\"none\"'),
('fields.31cc93a2-d38f-4943-b7c2-473b72eb69a1.type','\"simplicateca\\\\selectplus\\\\fields\\\\SelectPlusField\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.columnSuffix','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.handle','\"images\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.instructions','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.name','\"Images\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.searchable','true'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.allowedKinds.0','\"image\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.allowSelfRelations','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.allowSubfolders','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.allowUploads','true'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.branchLimit','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.defaultUploadLocationSource','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.defaultUploadLocationSubpath','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.localizeRelations','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.maintainHierarchy','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.maxRelations','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.minRelations','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.previewMode','\"full\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.restrictedDefaultUploadSubpath','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.restrictedLocationSource','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.restrictedLocationSubpath','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.restrictFiles','true'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.restrictLocation','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.selectionLabel','\"Choose\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.showCardsInGrid','true'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.showSiteMenu','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.showUnpermittedFiles','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.showUnpermittedVolumes','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.sources','\"*\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.targetSiteId','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.validateRelatedElements','false'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.settings.viewMode','\"cards\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.translationKeyFormat','null'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.translationMethod','\"site\"'),
('fields.4b104ed0-4b08-424b-a744-f9bbf418fc2f.type','\"craft\\\\fields\\\\Assets\"'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.columnSuffix','null'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.handle','\"color\"'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.instructions','null'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.name','\"Color\"'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.searchable','false'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.settings.defaultColor','null'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.translationKeyFormat','null'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.translationMethod','\"none\"'),
('fields.581b9070-f50c-49a0-91c7-2921437ad0fb.type','\"craft\\\\fields\\\\Color\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.columnSuffix','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.handle','\"text\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.instructions','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.name','\"Text\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.searchable','true'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.availableTransforms','\"\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.availableVolumes','\"\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.ckeConfig','\"ef0d77ed-a6ab-49db-afe4-2be38730d402\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.createButtonLabel','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.defaultTransform','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.enableSourceEditingForNonAdmins','false'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.purifierConfig','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.purifyHtml','true'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.showUnpermittedFiles','false'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.showUnpermittedVolumes','false'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.showWordCount','false'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.settings.wordLimit','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.translationKeyFormat','null'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.translationMethod','\"none\"'),
('fields.7487ca3f-f51b-40e9-a538-40ab5b2c4a27.type','\"craft\\\\ckeditor\\\\Field\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.columnSuffix','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.handle','\"bits\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.instructions','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.name','\"Bits\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.searchable','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.allowSelfRelations','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.branchLimit','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.localizeRelations','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.maintainHierarchy','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.maxRelations','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.minRelations','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.1.1','\"global\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.2.0','\"class\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.0','\"conditionRules\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.0','\"class\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\TypeConditionRule\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.0','\"uid\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.1','\"eaf7301f-e1b9-40c7-9b79-eb4dbcd116af\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.0','\"operator\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.1','\"in\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.0','\"values\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.1.0','\"1eb561c2-313a-4ea5-9332-dd8effd8eb73\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.selectionLabel','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.showCardsInGrid','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.showSiteMenu','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.sources.0','\"section:685e625d-7180-40dc-a031-953f5f9a8cef\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.targetSiteId','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.validateRelatedElements','false'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.settings.viewMode','\"list\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.translationKeyFormat','null'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.translationMethod','\"site\"'),
('fields.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2.type','\"craft\\\\fields\\\\Entries\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.columnSuffix','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.handle','\"bodyBuilder\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.instructions','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.name','\"Body Builder\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.searchable','true'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.createButtonLabel','\"Add Block\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.0','\"14dff90f-f8fc-444e-bc75-e51f72aa490d\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.1','\"4248eeb1-ca4d-476f-9998-7780ee611c74\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.2','\"96192f21-960f-489c-a380-96e4b51f2777\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.3','\"b4783a60-e9ff-40a2-8e9e-159b24fad0a9\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.4','\"faaa512e-f0ed-4151-97de-d73bdc9a4f5e\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.entryTypes.5','\"06d15756-5b0e-4a06-a8db-0f2343d4b25f\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.includeTableView','false'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.maxEntries','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.minEntries','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.pageSize','50'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.propagationKeyFormat','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.propagationMethod','\"all\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.showCardsInGrid','false'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.settings.viewMode','\"cards\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.translationKeyFormat','null'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.translationMethod','\"site\"'),
('fields.b4753be4-da84-4306-82e8-a9473ca5398f.type','\"craft\\\\fields\\\\Matrix\"'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.columnSuffix','null'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.handle','\"icon\"'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.instructions','null'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.name','\"Icon\"'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.searchable','false'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.translationKeyFormat','null'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.translationMethod','\"none\"'),
('fields.b54aca1f-5631-4f76-a248-e953c4ada5bd.type','\"craft\\\\fields\\\\Icon\"'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.columnSuffix','null'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.handle','\"website\"'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.instructions','null'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.name','\"Website / Content URL\"'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.searchable','false'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.settings.maxLength','255'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.settings.types.0','\"url\"'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.translationKeyFormat','null'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.translationMethod','\"none\"'),
('fields.d554a8e7-e8ad-493b-aaa8-d611bf04b257.type','\"craft\\\\fields\\\\Url\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.columnSuffix','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.handle','\"media\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.instructions','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.name','\"Media\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.searchable','true'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.0','\"audio\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.1','\"compressed\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.2','\"excel\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.3','\"pdf\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.4','\"powerpoint\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.5','\"video\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowedKinds.6','\"word\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowSelfRelations','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowSubfolders','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.allowUploads','true'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.branchLimit','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.defaultUploadLocationSource','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.defaultUploadLocationSubpath','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.localizeRelations','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.maintainHierarchy','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.maxRelations','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.minRelations','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.previewMode','\"full\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.restrictedDefaultUploadSubpath','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.restrictedLocationSource','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.restrictedLocationSubpath','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.restrictFiles','true'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.restrictLocation','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.selectionLabel','\"Choose\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.showCardsInGrid','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.showSiteMenu','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.showUnpermittedFiles','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.showUnpermittedVolumes','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.sources','\"*\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.targetSiteId','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.validateRelatedElements','false'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.settings.viewMode','\"cards\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.translationKeyFormat','null'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.translationMethod','\"site\"'),
('fields.d8bf6768-4ff5-4727-ac20-12f8f0344542.type','\"craft\\\\fields\\\\Assets\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.columnSuffix','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.handle','\"entries\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.instructions','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.name','\"Entries\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.searchable','true'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.allowSelfRelations','false'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.branchLimit','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.localizeRelations','false'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.maintainHierarchy','false'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.maxRelations','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.minRelations','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.selectionLabel','\"Choose\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.showCardsInGrid','true'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.showSiteMenu','true'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.sources','\"*\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.targetSiteId','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.validateRelatedElements','false'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.settings.viewMode','\"cards\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.translationKeyFormat','null'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.translationMethod','\"site\"'),
('fields.f240ce26-8d9d-4668-b18b-73371d5c5211.type','\"craft\\\\fields\\\\Entries\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.columnSuffix','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.handle','\"summary\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.instructions','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.name','\"Summary\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.searchable','true'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.availableTransforms','\"\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.availableVolumes','\"\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.ckeConfig','\"ef0d77ed-a6ab-49db-afe4-2be38730d402\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.createButtonLabel','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.defaultTransform','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.enableSourceEditingForNonAdmins','false'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.purifierConfig','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.purifyHtml','true'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.showUnpermittedFiles','false'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.showUnpermittedVolumes','false'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.showWordCount','true'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.settings.wordLimit','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.translationKeyFormat','null'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.translationMethod','\"none\"'),
('fields.f3d34d10-7741-40ba-9fae-27d87f771b4d.type','\"craft\\\\ckeditor\\\\Field\"'),
('meta.__names__.06d15756-5b0e-4a06-a8db-0f2343d4b25f','\"Fragment\"'),
('meta.__names__.0c3eb4bf-9fe7-422e-9947-289edfc00105','\"Redirect\"'),
('meta.__names__.14dff90f-f8fc-444e-bc75-e51f72aa490d','\"Text\"'),
('meta.__names__.1eb561c2-313a-4ea5-9332-dd8effd8eb73','\"Bit\"'),
('meta.__names__.1fc4d14e-bdf2-4cfa-a95c-64f6dac73d40','\"Collections\"'),
('meta.__names__.21710874-0ba0-423c-82ec-7fd855abb982','\"Dynamic Collection\"'),
('meta.__names__.247cf34e-12cf-4324-b034-3209f48a18ff','\"Page Content\"'),
('meta.__names__.2508516d-3329-44ec-8518-04f2a29ca3f3','\"External Media\"'),
('meta.__names__.31cc93a2-d38f-4943-b7c2-473b72eb69a1','\"Variant\"'),
('meta.__names__.4248eeb1-ca4d-476f-9998-7780ee611c74','\"Image\"'),
('meta.__names__.4688dcb4-257f-4a94-b8b7-db234f63e0a9','\"Landing Pages\"'),
('meta.__names__.4b104ed0-4b08-424b-a744-f9bbf418fc2f','\"Images\"'),
('meta.__names__.4b2a900b-f8d6-4b24-aee5-10ebc4051eb6','\"RSS Feed\"'),
('meta.__names__.581b9070-f50c-49a0-91c7-2921437ad0fb','\"Color\"'),
('meta.__names__.667ee826-8732-4bc8-8dbe-b7aefad82b15','\"Collections\"'),
('meta.__names__.685e625d-7180-40dc-a031-953f5f9a8cef','\"Reusable Pieces\"'),
('meta.__names__.7487ca3f-f51b-40e9-a538-40ab5b2c4a27','\"Text\"'),
('meta.__names__.80b8014d-fa4b-4271-9c59-73cd7c7c6d78','\"Article\"'),
('meta.__names__.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e','\"Taxonomies\"'),
('meta.__names__.8b83b1c6-3917-4365-bc67-1f94599cbb08','\"Private\"'),
('meta.__names__.93a86902-7a1b-4986-ba7f-35cef71233ac','\"Craft CMS\"'),
('meta.__names__.96192f21-960f-489c-a380-96e4b51f2777','\"Card Deck\"'),
('meta.__names__.99d1e742-e9ee-4468-8f52-06f9672d8f68','\"Fullpage\"'),
('meta.__names__.a28f735a-3f02-4039-aaf6-a9c50e93122f','\"Sidebar\"'),
('meta.__names__.ab7d33f0-3a17-47ea-a6a8-ad94734ee9a2','\"Bits\"'),
('meta.__names__.b1ee8bc9-827b-4fec-943c-c6ff229adb59','\"Articles\"'),
('meta.__names__.b4753be4-da84-4306-82e8-a9473ca5398f','\"Body Builder\"'),
('meta.__names__.b4783a60-e9ff-40a2-8e9e-159b24fad0a9','\"Media\"'),
('meta.__names__.b54aca1f-5631-4f76-a248-e953c4ada5bd','\"Icon\"'),
('meta.__names__.bb561dd8-e748-4c68-9107-2ffd5db410d8','\"Topic\"'),
('meta.__names__.d34bee8e-bf22-451d-8339-a4342630833d','\"Craft CMS\"'),
('meta.__names__.d554a8e7-e8ad-493b-aaa8-d611bf04b257','\"Website / Content URL\"'),
('meta.__names__.d7748b2a-ae79-4961-b103-a5aa758e39ab','\"Static Collection\"'),
('meta.__names__.d8bf6768-4ff5-4727-ac20-12f8f0344542','\"Media\"'),
('meta.__names__.e56447b6-2288-47ba-89a8-e90f3970f3c7','\"Sidebar Fragment\"'),
('meta.__names__.ef0d77ed-a6ab-49db-afe4-2be38730d402','\"Simple\"'),
('meta.__names__.f240ce26-8d9d-4668-b18b-73371d5c5211','\"Entries\"'),
('meta.__names__.f3d34d10-7741-40ba-9fae-27d87f771b4d','\"Summary\"'),
('meta.__names__.faaa512e-f0ed-4151-97de-d73bdc9a4f5e','\"Component\"'),
('meta.__names__.ff76eb70-820e-4752-b138-daef62692e3f','\"Body Fragment\"'),
('plugins.ckeditor.edition','\"standard\"'),
('plugins.ckeditor.enabled','true'),
('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),
('plugins.empty-coalesce.edition','\"standard\"'),
('plugins.empty-coalesce.enabled','true'),
('plugins.empty-coalesce.schemaVersion','\"1.0.0\"'),
('plugins.navigation.edition','\"standard\"'),
('plugins.navigation.enabled','true'),
('plugins.navigation.licenseKey','\"UOS5WIL2BA65FWV43LPHM9NT\"'),
('plugins.navigation.schemaVersion','\"2.1.0\"'),
('plugins.retcon.edition','\"standard\"'),
('plugins.retcon.enabled','true'),
('plugins.retcon.schemaVersion','\"1.0.0\"'),
('plugins.selectplus.edition','\"standard\"'),
('plugins.selectplus.enabled','true'),
('plugins.selectplus.schemaVersion','\"1.0.0\"'),
('plugins.seomatic.edition','\"standard\"'),
('plugins.seomatic.enabled','true'),
('plugins.seomatic.licenseKey','\"8F7J3RTMNWCHFZDNV5PYH126\"'),
('plugins.seomatic.schemaVersion','\"3.0.12\"'),
('plugins.sprig.edition','\"standard\"'),
('plugins.sprig.enabled','true'),
('plugins.sprig.schemaVersion','\"1.0.1\"'),
('plugins.vite.edition','\"standard\"'),
('plugins.vite.enabled','true'),
('plugins.vite.schemaVersion','\"1.0.0\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.defaultPlacement','\"end\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.enableVersioning','true'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.entryTypes.0','\"99d1e742-e9ee-4468-8f52-06f9672d8f68\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.entryTypes.1','\"a28f735a-3f02-4039-aaf6-a9c50e93122f\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.handle','\"pages\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.maxAuthors','1'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.name','\"Page Content\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.propagationMethod','\"all\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','true'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','\"_site/pages._entry.twig\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','\"{% from \'_site/pages._entry\' import uri %}{{ uri( object ) }}\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.structure.maxLevels','null'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.structure.uid','\"55f15188-2e0e-4284-9978-2e6b6786e26a\"'),
('sections.247cf34e-12cf-4324-b034-3209f48a18ff.type','\"structure\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.defaultPlacement','\"end\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.enableVersioning','true'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.entryTypes.0','\"99d1e742-e9ee-4468-8f52-06f9672d8f68\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.entryTypes.1','\"0c3eb4bf-9fe7-422e-9947-289edfc00105\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.handle','\"landingPages\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.maxAuthors','1'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.name','\"Landing Pages\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.propagationMethod','\"all\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','true'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','\"_site/pages._entry.twig\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','\"{% from \'_site/pages._entry\' import uri %}{{ uri( object ) }}\"'),
('sections.4688dcb4-257f-4a94-b8b7-db234f63e0a9.type','\"channel\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.defaultPlacement','\"end\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.enableVersioning','true'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.entryTypes.0','\"21710874-0ba0-423c-82ec-7fd855abb982\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.entryTypes.1','\"d7748b2a-ae79-4961-b103-a5aa758e39ab\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.entryTypes.2','\"4b2a900b-f8d6-4b24-aee5-10ebc4051eb6\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.handle','\"collections\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.maxAuthors','1'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.name','\"Collections\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.propagationMethod','\"all\"'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','false'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','null'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','null'),
('sections.667ee826-8732-4bc8-8dbe-b7aefad82b15.type','\"channel\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.defaultPlacement','\"end\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.enableVersioning','true'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.entryTypes.0','\"1eb561c2-313a-4ea5-9332-dd8effd8eb73\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.entryTypes.1','\"ff76eb70-820e-4752-b138-daef62692e3f\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.entryTypes.2','\"e56447b6-2288-47ba-89a8-e90f3970f3c7\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.handle','\"reusable\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.maxAuthors','1'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.name','\"Reusable Pieces\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.propagationMethod','\"all\"'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','false'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','null'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','null'),
('sections.685e625d-7180-40dc-a031-953f5f9a8cef.type','\"channel\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.defaultPlacement','\"end\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.enableVersioning','true'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.entryTypes.0','\"99d1e742-e9ee-4468-8f52-06f9672d8f68\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.entryTypes.1','\"a28f735a-3f02-4039-aaf6-a9c50e93122f\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.handle','\"taxonomy\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.maxAuthors','1'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.name','\"Taxonomies\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.propagationMethod','\"all\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','true'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','\"_site/taxonomy._entry.twig\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','\"{% from \'_site/taxonomy._entry\' import uri %}{{ uri( object ) }}\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.structure.maxLevels','null'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.structure.uid','\"cc00ceed-0937-472c-b55c-c83fa5fce262\"'),
('sections.83a6e4e2-3e52-435e-bcb4-ced4dc7e387e.type','\"structure\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.defaultPlacement','\"end\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.enableVersioning','true'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.entryTypes.0','\"80b8014d-fa4b-4271-9c59-73cd7c7c6d78\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.handle','\"articles\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.maxAuthors','1'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.name','\"Articles\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.propagationMethod','\"all\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.enabledByDefault','true'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','true'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.template','\"_site/articles._entry.twig\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.siteSettings.d34bee8e-bf22-451d-8339-a4342630833d.uriFormat','\"{% from \'_site/articles._entry\' import uri %}{{ uri( object ) }}\"'),
('sections.b1ee8bc9-827b-4fec-943c-c6ff229adb59.type','\"channel\"'),
('siteGroups.93a86902-7a1b-4986-ba7f-35cef71233ac.name','\"Craft CMS\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.handle','\"default\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.hasUrls','true'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.language','\"en-CA\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.name','\"Craft CMS\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.primary','true'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.siteGroup','\"93a86902-7a1b-4986-ba7f-35cef71233ac\"'),
('sites.d34bee8e-bf22-451d-8339-a4342630833d.sortOrder','1'),
('system.edition','\"solo\"'),
('system.live','true'),
('system.name','\"Craft CMS\"'),
('system.schemaVersion','\"5.0.0.20\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.require2fa','false'),
('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES
(1,3,1,1,''),
(2,61,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES
(1,'email',0,1,' craft example com '),
(1,'firstname',0,1,''),
(1,'fullname',0,1,''),
(1,'lastname',0,1,''),
(1,'slug',0,1,''),
(1,'username',0,1,' craft example com '),
(2,'slug',0,1,' temp tvcxxkceprbtfvgcysskjffjoezhrelfdhlz '),
(2,'title',0,1,''),
(3,'field',10,1,''),
(3,'slug',0,1,' home '),
(3,'title',0,1,' home '),
(4,'slug',0,1,' temp wdbpnswqcxpskonwdnynhvrykhntjkjgetmv '),
(4,'title',0,1,''),
(59,'slug',0,1,' temp yoadwltsnnhcpmtnrttkbfzsgxnhfzbtjrul '),
(59,'title',0,1,''),
(60,'slug',0,1,' temp mhdhtxaaladldkednrxojyceuwwwlgqbfyny '),
(60,'title',0,1,''),
(61,'field',6,1,' neminem videbis ita laudatum ut artifex callidus comparandarum voluptatum diceretur lorem ipsum dolor sit amet consectetur adipiscing elit duo reges constructio interrete nescio quo modo praetervolavit oratio idemque diviserunt naturam hominis in animum et corpus erat enim polemonis quamquam haec quidem praeposita recte et reiecta dicere licebit si longus levis dictata sunt '),
(61,'field',8,1,''),
(61,'slug',0,1,' temp kluvpztofsfinpaznyqvwkkowakqlvkvcane '),
(61,'title',0,1,''),
(68,'field',10,1,' neminem videbis ita laudatum ut artifex callidus comparandarum voluptatum diceretur lorem ipsum dolor sit amet consectetur adipiscing elit duo reges constructio interrete nescio quo modo praetervolavit oratio idemque diviserunt naturam hominis in animum et corpus erat enim polemonis quamquam haec quidem praeposita recte et reiecta dicere licebit si longus levis dictata sunt '),
(68,'slug',0,1,' home '),
(68,'title',0,1,' home '),
(69,'slug',0,1,' temp vxlzfanqcibpyqwxzenbdypwosvzkgxyvwlo '),
(69,'title',0,1,''),
(71,'field',6,1,''),
(71,'field',8,1,''),
(71,'slug',0,1,' temp kluvpztofsfinpaznyqvwkkowakqlvkvcane '),
(71,'title',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES
(1,1,'Page Content','pages','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 22:36:27','2024-04-27 23:35:01',NULL,'247cf34e-12cf-4324-b034-3209f48a18ff'),
(2,NULL,'Articles','articles','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 23:30:32','2024-04-27 23:30:32',NULL,'b1ee8bc9-827b-4fec-943c-c6ff229adb59'),
(3,NULL,'Collections','collections','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 23:32:31','2024-04-27 23:32:31',NULL,'667ee826-8732-4bc8-8dbe-b7aefad82b15'),
(4,NULL,'Landing Pages','landingPages','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 23:36:28','2024-04-27 23:36:28',NULL,'4688dcb4-257f-4a94-b8b7-db234f63e0a9'),
(5,NULL,'Reusable Pieces','reusable','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 23:44:10','2024-04-27 23:50:12',NULL,'685e625d-7180-40dc-a031-953f5f9a8cef'),
(6,2,'Taxonomies','taxonomy','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-27 23:46:36','2024-04-28 00:57:51',NULL,'83a6e4e2-3e52-435e-bcb4-ced4dc7e387e');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES
(1,1,1),
(1,2,2),
(2,9,1),
(3,11,1),
(3,12,2),
(3,13,3),
(4,1,1),
(4,18,2),
(5,10,1),
(5,14,3),
(5,15,2),
(6,1,1),
(6,2,2);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'{% from \'_site/pages._entry\' import uri %}{{ uri( object ) }}','_site/pages._entry.twig',1,'2024-04-27 22:36:27','2024-04-28 00:57:02','f5e1e170-abcd-4cb9-acc9-73e0e5e8c517'),
(2,2,1,1,'{% from \'_site/articles._entry\' import uri %}{{ uri( object ) }}','_site/articles._entry.twig',1,'2024-04-27 23:30:32','2024-04-28 00:56:42','d73751f9-4f81-4aac-876e-50e75e7fa8de'),
(3,3,1,0,NULL,NULL,1,'2024-04-27 23:32:31','2024-04-27 23:32:31','69323219-6695-4ee0-bc65-3602a49c4158'),
(4,4,1,1,'{% from \'_site/pages._entry\' import uri %}{{ uri( object ) }}','_site/pages._entry.twig',1,'2024-04-27 23:36:28','2024-04-28 00:56:58','2ef081f4-3989-4e3d-93d1-dfaed36e64a3'),
(5,5,1,0,NULL,NULL,1,'2024-04-27 23:44:10','2024-04-27 23:44:10','8313c453-a8e0-4353-9fc4-a503f5e70918'),
(6,6,1,1,'{% from \'_site/taxonomy._entry\' import uri %}{{ uri( object ) }}','_site/taxonomy._entry.twig',1,'2024-04-27 23:46:36','2024-04-28 00:57:13','63a40bb1-bd17-4a4f-81c8-38b1f4ebf701');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `seomatic_metabundles` VALUES
(1,'2024-04-30 03:55:01','2024-04-30 03:55:01','5442a02f-73bd-49d9-b122-56290a313bfc','1.0.71','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',1,'[]','2024-04-30 03:55:01','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ seomatic.helper.safeCanonicalUrl() }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Craft CMS\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapAssetTransform\":null,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]},\"tagAttrs\":[]},\"keywords\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoKeywords }}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoDescription }}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"referrer\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.referrer }}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"robots\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.robots }}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{{ seomatic.meta.robots }}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookProfileId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookAppId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:site_name\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.siteName }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:type\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogType }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:url\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.canonicalUrl }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.ogSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogTitle }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImage }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"facebook-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"facebook-domain-verification\",\"property\":null,\"include\":true,\"key\":\"facebook-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"facebookSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterCard }}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{{ seomatic.site.twitterHandle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"tagAttrs\":[]},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{{ seomatic.meta.twitterCreator }}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]},\"tagAttrs\":[]},\"twitter:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.twitterSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterTitle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImage }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":null,\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.googleSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]},\"tagAttrs\":[]},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.bingSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]},\"tagAttrs\":[]},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.pinterestSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.meta.canonicalUrl }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"\\/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"\\/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text\\/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]},\"tagAttrs\":[]},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.site.googlePublisherLink }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]},\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https:\\/\\/developers.google.com\\/gtagjs\\/)\",\"templatePath\":\"_frontend\\/scripts\\/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"><\\/script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Measurement\\/Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `G-XXXXXXXXXX` or `UA-XXXXXX-XX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/analytics\\/answer\\/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.google.com\\/adwords-remarketing-tag\\/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/dcm\\/partner\\/answer\\/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/gtag\\/js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https:\\/\\/support.google.com\\/tagmanager\\/answer\\/6102821?hl=en)\",\"templatePath\":\"_frontend\\/scripts\\/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"><\\/iframe><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.google.com\\/tag-manager\\/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/ns.html\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https:\\/\\/www.facebook.com\\/business\\/help\\/651294705016616)\",\"templatePath\":\"_frontend\\/scripts\\/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" \\/><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.facebook.com\\/docs\\/facebook-pixel\\/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/connect.facebook.net\\/en_US\\/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.facebook.com\\/tr\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend\\/scripts\\/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text\\/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text\\/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n<\\/script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" \\/>\\n<\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/www.linkedin.com\\/help\\/lms\\/answer\\/65513\\/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/snap.licdn.com\\/li.lms-analytics\\/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/dc.ads.linkedin.com\\/collect\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text\\/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"><\\/script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/knowledge.hubspot.com\\/articles\\/kcs_article\\/reports\\/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"\\/\\/js.hs-scripts.com\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"pinterestTag\":{\"name\":\"Pinterest Tag\",\"description\":\"The Pinterest tag allows you to track actions people take on your website after viewing your Promoted Pin. You can use this information to measure return on ad spend (RoAS) and create audiences to target on your Promoted Pins. [Learn More](https:\\/\\/help.pinterest.com\\/en\\/business\\/article\\/track-conversions-with-pinterest-tag)\",\"templatePath\":\"_frontend\\/scripts\\/pinterestTagHead.twig\",\"templateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n!function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(\\nArray.prototype.slice.call(arguments))};var\\nn=window.pintrk;n.queue=[],n.version=\\\"3.0\\\";var\\nt=document.createElement(\\\"script\\\");t.async=!0,t.src=e;var\\nr=document.getElementsByTagName(\\\"script\\\")[0];r.parentNode.insertBefore(t,r)}}(\\\"{{ pinterestTagUrl.value }}\\\");\\npintrk(\'load\', \'{{ pinterestTagId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\npintrk(\'page\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/pinterestTagBody.twig\",\"bodyTemplateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ pinterestTagNoScriptUrl.value }}?tid={{ pinterestTagId.value }}&noscript=1\\\" \\/><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"pinterestTagId\":{\"title\":\"Pinterest Tag ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.pinterest.com\\/docs\\/ad-tools\\/conversion-tag\\/)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Pinterest Tag PageView\",\"instructions\":\"Controls whether the Pinterest Tag script automatically sends a PageView to when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"pinterestTagUrl\":{\"title\":\"Pinterest Tag Script URL\",\"instructions\":\"The URL to the Pinterest Tag script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/s.pinimg.com\\/ct\\/core.js\"},\"pinterestTagNoScriptUrl\":{\"title\":\"Pinterest Tag Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Pinterest Tag `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/ct.pinterest.com\\/v3\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"pinterestTag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"fathom\":{\"name\":\"Fathom\",\"description\":\"Fathom is a simple, light-weight, privacy-first alternative to Google Analytics. So, stop scrolling through pages of reports and collecting gobs of personal data about your visitors, both of which you probably don’t need. [Learn More](https:\\/\\/usefathom.com\\/)\",\"templatePath\":\"_frontend\\/scripts\\/fathomAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-site\\\", \\\"{{ siteId.value | raw }}\\\");\\n{% if honorDnt.value %}\\ntag.setAttribute(\\\"data-honor-dnt\\\", \\\"true\\\");\\n{% endif %}\\n{% if disableAutoTracking.value %}\\ntag.setAttribute(\\\"data-auto\\\", \\\"false\\\");\\n{% endif %}\\n{% if ignoreCanonicals.value %}\\ntag.setAttribute(\\\"data-canonical\\\", \\\"false\\\");\\n{% endif %}\\n{% if excludedDomains.value | length %}\\ntag.setAttribute(\\\"data-excluded-domains\\\", \\\"{{ excludedDomains.value | raw }}\\\");\\n{% endif %}\\n{% if includedDomains.value | length %}\\ntag.setAttribute(\\\"data-included-domains\\\", \\\"{{ includedDomains.value | raw }}\\\");\\n{% endif %}\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking)\",\"type\":\"string\",\"value\":\"\"},\"honorDnt\":{\"title\":\"Honoring Do Not Track (DNT)\",\"instructions\":\"By default we track every visitor to your website, regardless of them having DNT turned on or not. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"disableAutoTracking\":{\"title\":\"Disable automatic tracking\",\"instructions\":\"By default, we track a page view every time a visitor to your website loads a page with our script on it. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"ignoreCanonicals\":{\"title\":\"Ignore canonicals\",\"instructions\":\"If there’s a canonical URL in place, then by default we use it instead of the current URL. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"excludedDomains\":{\"title\":\"Excluded Domains\",\"instructions\":\"You exclude one or several domains, so our tracker will track things on every domain, except the ones excluded. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"includedDomains\":{\"title\":\"Included Domains\",\"instructions\":\"If you want to go in the opposite direction and only track stats on a specific domain. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Fathom Script URL\",\"instructions\":\"The URL to the Fathom tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/cdn.usefathom.com\\/script.js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"fathom\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"matomo\":{\"name\":\"Matomo\",\"description\":\"Matomo is a Google Analytics alternative that protects your data and your customers\' privacy [Learn More](https:\\/\\/matomo.org\\/)\",\"templatePath\":\"_frontend\\/scripts\\/matomoAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value and scriptUrl.value is defined and scriptUrl.value | length %}\\nvar _paq = window._paq = window._paq || [];\\n{% if sendPageView.value %}\\n_paq.push([\'trackPageView\']);\\n{% endif %}\\n{% if sendPageView.value %}\\n_paq.push([\'enableLinkTracking\']);\\n{% endif %}\\n(function() {\\nvar u=\\\"{{ scriptUrl.value }}\\\";\\n_paq.push([\'setTrackerUrl\', u+\'matomo.php\']);\\n_paq.push([\'setSiteId\', {{ siteId.value }}]);\\nvar d=document, g=d.createElement(\'script\'), s=d.getElementsByTagName(\'script\')[0];\\ng.type=\'text\\/javascript\'; g.async=true; g.src=u+\'matomo.js\'; s.parentNode.insertBefore(g,s);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https:\\/\\/developer.matomo.org\\/guides\\/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Matomo PageView\",\"instructions\":\"Controls whether the Matomo script automatically sends a PageView when your pages are loaded. [Learn More](https:\\/\\/developer.matomo.org\\/api-reference\\/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"enableLinkTracking\":{\"title\":\"Enable Link Tracking\",\"instructions\":\"Install link tracking on all applicable link elements. [Learn More](https:\\/\\/developer.matomo.org\\/api-reference\\/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"scriptUrl\":{\"title\":\"Matomo Script URL\",\"instructions\":\"The URL to the Matomo tracking script. This will vary depending on whether you are using Matomo Cloud or Matomo On-Premise. [Learn More](https:\\/\\/developer.matomo.org\\/guides\\/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"matomo\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"plausible\":{\"name\":\"Plausible\",\"description\":\"Plausible is a lightweight and open-source website analytics tool. No cookies and fully compliant with GDPR, CCPA and PECR. [Learn More](https:\\/\\/plausible.io\\/)\",\"templatePath\":\"_frontend\\/scripts\\/plausibleAnalytics.twig\",\"templateString\":\"{% if siteDomain.value is defined and siteDomain.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-domain\\\", \\\"{{ siteDomain.value | raw }}\\\");\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteDomain\":{\"title\":\"Site Domain\",\"instructions\":\"Only enter the site domain, not the entire script code. [Learn More](https:\\/\\/plausible.io\\/docs\\/plausible-script)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Plausible Script URL\",\"instructions\":\"The URL to the Plausible tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/plausible.io\\/js\\/plausible.js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"plausible\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleAnalytics\":{\"name\":\"Google Analytics (old)\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https:\\/\\/www.google.com\\/analytics\\/analytics\\/)\",\"templatePath\":\"_frontend\\/scripts\\/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/analytics\\/answer\\/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.google-analytics.com\\/analytics.js\"}},\"dataLayer\":[],\"deprecated\":true,\"deprecationNotice\":\"Universal Analytics (which is what this script uses) is being [discontinued on July 1st, 2023](https:\\/\\/support.google.com\\/analytics\\/answer\\/11583528). You should use Google gtag.js or Google Tag Manager instead and transition to a new GA4 property.\",\"discontinued\":false,\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"dateModified\":null,\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":null,\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":null,\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":null,\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":null,\"isAccessibleForFree\":null,\"dateCreated\":null,\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":{\"type\":\"EntryPoint\",\"urlTemplate\":\"{{ seomatic.site.siteLinksSearchTarget }}\"},\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"},\"identity\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.site.identity.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"memberOf\":null,\"foundingLocation\":\"{{ seomatic.site.identity.organizationFoundingLocation }}\",\"hasOfferCatalog\":null,\"awards\":null,\"alumni\":null,\"nonprofitStatus\":null,\"slogan\":null,\"owns\":null,\"award\":null,\"event\":null,\"makesOffer\":null,\"review\":null,\"hasPOS\":null,\"duns\":\"{{ seomatic.site.identity.organizationDuns }}\",\"brand\":null,\"knowsLanguage\":null,\"department\":null,\"knowsAbout\":null,\"foundingDate\":\"{{ seomatic.site.identity.organizationFoundingDate }}\",\"diversityPolicy\":null,\"leiCode\":null,\"publishingPrinciples\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"ownershipFundingInfo\":null,\"reviews\":null,\"isicV4\":null,\"telephone\":\"{{ seomatic.site.identity.genericTelephone }}\",\"location\":null,\"correctionsPolicy\":null,\"areaServed\":null,\"funding\":null,\"employee\":null,\"numberOfEmployees\":null,\"hasMerchantReturnPolicy\":null,\"iso6523Code\":null,\"taxID\":null,\"naics\":null,\"founders\":null,\"contactPoint\":null,\"serviceArea\":null,\"globalLocationNumber\":null,\"keywords\":null,\"email\":\"{{ seomatic.site.identity.genericEmail }}\",\"ethicsPolicy\":null,\"sponsor\":null,\"agentInteractionStatistic\":null,\"employees\":null,\"events\":null,\"interactionStatistic\":null,\"legalName\":null,\"vatID\":null,\"members\":null,\"funder\":null,\"aggregateRating\":null,\"hasCredential\":null,\"seeks\":null,\"subOrganization\":null,\"dissolutionDate\":null,\"contactPoints\":[],\"founder\":\"{{ seomatic.site.identity.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"parentOrganization\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.identity.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.identity.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.identity.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.identity.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.identity.genericAddressCountry }}\"},\"faxNumber\":null,\"actionableFeedbackPolicy\":null,\"diversityStaffingReport\":null,\"hasCertification\":null,\"member\":null,\"name\":\"{{ seomatic.site.identity.genericName }}\",\"description\":\"{{ seomatic.site.identity.genericDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.site.identity.genericUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.identity.genericImage }}\",\"width\":\"{{ seomatic.site.identity.genericImageWidth }}\",\"height\":\"{{ seomatic.site.identity.genericImageHeight }}\"},\"additionalType\":null,\"potentialAction\":null,\"alternateName\":\"{{ seomatic.site.identity.genericAlternateName }}\",\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":null},\"creator\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.site.creator.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"memberOf\":null,\"foundingLocation\":\"{{ seomatic.site.creator.organizationFoundingLocation }}\",\"hasOfferCatalog\":null,\"awards\":null,\"alumni\":null,\"nonprofitStatus\":null,\"slogan\":null,\"owns\":null,\"award\":null,\"event\":null,\"makesOffer\":null,\"review\":null,\"hasPOS\":null,\"duns\":\"{{ seomatic.site.creator.organizationDuns }}\",\"brand\":null,\"knowsLanguage\":null,\"department\":null,\"knowsAbout\":null,\"foundingDate\":\"{{ seomatic.site.creator.organizationFoundingDate }}\",\"diversityPolicy\":null,\"leiCode\":null,\"publishingPrinciples\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"ownershipFundingInfo\":null,\"reviews\":null,\"isicV4\":null,\"telephone\":\"{{ seomatic.site.creator.genericTelephone }}\",\"location\":null,\"correctionsPolicy\":null,\"areaServed\":null,\"funding\":null,\"employee\":null,\"numberOfEmployees\":null,\"hasMerchantReturnPolicy\":null,\"iso6523Code\":null,\"taxID\":null,\"naics\":null,\"founders\":null,\"contactPoint\":null,\"serviceArea\":null,\"globalLocationNumber\":null,\"keywords\":null,\"email\":\"{{ seomatic.site.creator.genericEmail }}\",\"ethicsPolicy\":null,\"sponsor\":null,\"agentInteractionStatistic\":null,\"employees\":null,\"events\":null,\"interactionStatistic\":null,\"legalName\":null,\"vatID\":null,\"members\":null,\"funder\":null,\"aggregateRating\":null,\"hasCredential\":null,\"seeks\":null,\"subOrganization\":null,\"dissolutionDate\":null,\"contactPoints\":[],\"founder\":\"{{ seomatic.site.creator.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"parentOrganization\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.creator.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.creator.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.creator.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.creator.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.creator.genericAddressCountry }}\"},\"faxNumber\":null,\"actionableFeedbackPolicy\":null,\"diversityStaffingReport\":null,\"hasCertification\":null,\"member\":null,\"name\":\"{{ seomatic.site.creator.genericName }}\",\"description\":\"{{ seomatic.site.creator.genericDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.site.creator.genericUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.creator.genericImage }}\",\"width\":\"{{ seomatic.site.creator.genericImageWidth }}\",\"height\":\"{{ seomatic.site.creator.genericImageHeight }}\"},\"additionalType\":null,\"potentialAction\":null,\"alternateName\":\"{{ seomatic.site.creator.genericAlternateName }}\",\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"\\/* TEAM *\\/\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n\\/a\\\" }}\\nURL: {{ parseEnv(seomatic.site.creator.genericUrl ?? \\\"n\\/a\\\") }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n\\/a\\\" }}\\n\\n\\/* THANKS *\\/\\n\\nCraft CMS - https:\\/\\/craftcms.com\\nPixel & Tonic - https:\\/\\/pixelandtonic.com\\n\\n\\/* SITE *\\/\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 5, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend\\/pages\\/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }}\\n\\n{{ seomatic.helper.sitemapIndex() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n    # live - don\'t allow web crawlers to index cpresources\\/ or vendor\\/\\n\\n    User-agent: *\\n    Disallow: \\/cpresources\\/\\n    Disallow: \\/vendor\\/\\n    Disallow: \\/.env\\n    Disallow: \\/cache\\/\\n\\n{% case \\\"staging\\\" %}\\n\\n    # staging - disallow all\\n\\n    User-agent: *\\n    Disallow: \\/\\n\\n{% case \\\"local\\\" %}\\n\\n    # local - disallow all\\n\\n    User-agent: *\\n    Disallow: \\/\\n\\n{% default %}\\n\\n    # default - don\'t allow web crawlers to index cpresources\\/ or vendor\\/\\n\\n    User-agent: *\\n    Disallow: \\/cpresources\\/\\n    Disallow: \\/vendor\\/\\n    Disallow: \\/.env\\n    Disallow: \\/cache\\/\\n\\n{% endswitch %}\\n\\n# Disallow ChatGPT bot, as there\'s no benefit to allowing it to index your site\\nUser-agent: GPTBot\\nDisallow: \\/\\n\\n# Disallow Google Bard and Vertex AI bots, as there\'s no benefit to allowing it to index your site\\nUser-agent: Google-Extended\\nDisallow: \\/\\n\\n# Disallow Perplexity bot, as there\'s no benefit to allowing it to index your site\\nUser-agent: PerplexityBot\\nDisallow: \\/\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend\\/pages\\/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }}\\n# More info: https:\\/\\/support.google.com\\/admanager\\/answer\\/7441288?hl=en\\n{{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }},123,DIRECT\\n\",\"siteId\":null,\"include\":false,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend\\/pages\\/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"},\"security\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# security.txt file for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }} - more info: https:\\/\\/securitytxt.org\\/\\n\\n# (required) Contact email address for security issues\\nContact: mailto:user@example.com\\n\\n# (required) Expiration date for the security information herein\\nExpires: {{ date(\'+1 year\')|atom }}\\n\\n# (optional) OpenPGP key:\\nEncryption: {{ url(\'pgp-key.txt\') }}\\n\\n# (optional) Security policy page:\\nPolicy: {{ url(\'security-policy\') }}\\n\\n# (optional) Security acknowledgements page:\\nAcknowledgements: {{ url(\'hall-of-fame\') }}\\n\",\"siteId\":null,\"include\":false,\"handle\":\"security\",\"path\":\".well-known\\/security.txt\",\"template\":\"_frontend\\/pages\\/security.twig\",\"controller\":\"frontend-template\",\"action\":\"security\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),
(2,'2024-04-30 03:55:01','2024-04-30 03:55:01','8c630da8-8cf8-4e1f-9c2d-9aeadaa13c46','1.0.31','section',2,'Articles','articles','channel',NULL,'_site/articles._entry.twig',1,'{\"1\":{\"id\":2,\"sectionId\":2,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{% from \'_site\\/articles._entry\' import uri %}{{ uri( object ) }}\",\"template\":\"_site\\/articles._entry.twig\",\"language\":\"en-ca\"}}','2024-04-30 03:55:01','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{{ entry.title }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"sameAsGlobal\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"sameAsGlobal\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Craft CMS\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapAssetTransform\":null,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"specialty\":null,\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"significantLinks\":null,\"reviewedBy\":null,\"relatedLink\":null,\"primaryImageOfPage\":null,\"significantLink\":null,\"speakable\":null,\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"isAccessibleForFree\":null,\"dateCreated\":\"{{ entry.dateCreated |atom }}\",\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),
(3,'2024-04-30 03:55:01','2024-04-30 03:55:01','0c4159a4-632e-4356-87f3-8aa3f6632119','1.0.31','section',4,'Landing Pages','landingPages','channel',NULL,'_site/pages._entry.twig',1,'{\"1\":{\"id\":4,\"sectionId\":4,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{% from \'_site\\/pages._entry\' import uri %}{{ uri( object ) }}\",\"template\":\"_site\\/pages._entry.twig\",\"language\":\"en-ca\"}}','2024-04-30 03:55:01','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{{ entry.title }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"sameAsGlobal\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"sameAsGlobal\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Craft CMS\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapAssetTransform\":null,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"specialty\":null,\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"significantLinks\":null,\"reviewedBy\":null,\"relatedLink\":null,\"primaryImageOfPage\":null,\"significantLink\":null,\"speakable\":null,\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"isAccessibleForFree\":null,\"dateCreated\":\"{{ entry.dateCreated |atom }}\",\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),
(4,'2024-04-30 03:55:01','2024-04-30 03:55:01','1029cd3a-710d-4eaa-9af7-2dd75cf74523','1.0.31','section',1,'Page Content','pages','structure',NULL,'_site/pages._entry.twig',1,'{\"1\":{\"id\":1,\"sectionId\":1,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{% from \'_site\\/pages._entry\' import uri %}{{ uri( object ) }}\",\"template\":\"_site\\/pages._entry.twig\",\"language\":\"en-ca\"}}','2024-04-30 03:46:39','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{{ entry.title }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"sameAsGlobal\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"sameAsGlobal\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Craft CMS\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapAssetTransform\":null,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"specialty\":null,\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"significantLinks\":null,\"reviewedBy\":null,\"relatedLink\":null,\"primaryImageOfPage\":null,\"significantLink\":null,\"speakable\":null,\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"isAccessibleForFree\":null,\"dateCreated\":\"{{ entry.dateCreated |atom }}\",\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),
(5,'2024-04-30 03:55:01','2024-04-30 03:55:01','631ee3b5-c4f3-4bab-91b7-8d237f347ca2','1.0.31','section',6,'Taxonomies','taxonomy','structure',NULL,'_site/taxonomy._entry.twig',1,'{\"1\":{\"id\":6,\"sectionId\":6,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{% from \'_site\\/taxonomy._entry\' import uri %}{{ uri( object ) }}\",\"template\":\"_site\\/taxonomy._entry.twig\",\"language\":\"en-ca\"}}','2024-04-30 03:55:01','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{{ entry.title }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"sameAsGlobal\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"sameAsGlobal\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Craft CMS\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapAssetTransform\":null,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"specialty\":null,\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"significantLinks\":null,\"reviewedBy\":null,\"relatedLink\":null,\"primaryImageOfPage\":null,\"significantLink\":null,\"speakable\":null,\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"isAccessibleForFree\":null,\"dateCreated\":\"{{ entry.dateCreated |atom }}\",\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES
(1,'Craft CMS','2024-04-27 22:26:07','2024-04-27 22:26:07',NULL,'93a86902-7a1b-4986-ba7f-35cef71233ac');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES
(1,1,1,'true','Craft CMS','default','en-CA',1,'$PRIMARY_SITE_URL',1,'2024-04-27 22:26:07','2024-04-27 22:26:07',NULL,'d34bee8e-bf22-451d-8339-a4342630833d');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sprig_playgrounds`
--

LOCK TABLES `sprig_playgrounds` WRITE;
/*!40000 ALTER TABLE `sprig_playgrounds` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sprig_playgrounds` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES
(1,1,NULL,1,1,6,0,'2024-04-28 01:00:58','2024-04-28 01:01:41','fbacd1e6-8272-4b4a-87c9-f29b3ad332b6'),
(2,1,2,1,2,3,1,'2024-04-28 01:00:58','2024-04-28 01:00:58','10d84e0e-4f63-4ba2-b970-84d7e1e133b9'),
(3,1,3,1,4,5,1,'2024-04-28 01:01:41','2024-04-28 01:01:41','16793e7d-db86-4c52-afac-895b4ccc12ca');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES
(1,NULL,'2024-04-27 22:36:27','2024-04-27 22:36:27',NULL,'55f15188-2e0e-4284-9978-2e6b6786e26a'),
(2,NULL,'2024-04-27 23:46:36','2024-04-27 23:46:36',NULL,'cc00ceed-0937-472c-b55c-c83fa5fce262');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tokens` VALUES
(1,'TBRQz-_6f0fzA319kaOKcGQYMg_8DN9i','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":3,\"siteId\":1,\"draftId\":10,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2024-05-01 03:46:12','2024-04-30 03:46:12','2024-04-30 03:46:12','c108bdf4-6eb7-46da-92b1-9f5c7121750c');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES
(1,'{\"language\": \"en-CA\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,NULL,1,0,0,0,1,'craft@example.com',NULL,NULL,NULL,'craft@example.com','$2y$13$YqCUNHk65ck8jsZ9OhnZGuMVPajNuTKNtbmj/FPVE2pcI/4Q2YGK6','2024-04-30 19:35:17',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-04-27 22:26:08','2024-04-27 22:26:08','2024-04-30 19:35:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES
(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-04-27 22:30:57','2024-04-27 22:30:57','997189c9-7a4a-4af9-90f7-8641075389c2'),
(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-04-27 22:30:57','2024-04-27 22:30:57','fdcf87fe-94cf-41d2-b8cc-19b4804526e0'),
(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-04-27 22:30:57','2024-04-27 22:30:57','acb84a7b-0fbd-4458-b64e-4c8878561180'),
(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-04-27 22:30:57','2024-04-27 22:30:57','f2e111c0-fb98-44e2-87bf-7d803077cd24');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'project'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 19:51:44
