SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `craft_addresses`;
CREATE TABLE `craft_addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_fk_atmaefctpiytnftefnxbgvzmjhbjctpugtpz` (`primaryOwnerId`),
  CONSTRAINT `craft_fk_atmaefctpiytnftefnxbgvzmjhbjctpugtpz` FOREIGN KEY (`primaryOwnerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_xkbdejglvpofgtoizjfotycxzlmwborzmzsf` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_announcements`;
CREATE TABLE `craft_announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_orfaxskonzvvhyifijkbxgmwiadontoyuamv` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `craft_idx_ykijemejfrlhpkskywnenybcjnqpumyuwopg` (`dateRead`),
  KEY `craft_fk_orpuucuqwkgpcopxjrnxlmpdfaqvyudaqfku` (`pluginId`),
  CONSTRAINT `craft_fk_orpuucuqwkgpcopxjrnxlmpdfaqvyudaqfku` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_quxnsyyyksknaqjfuhexluzwxaaeqsxfcudc` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_assetindexdata`;
CREATE TABLE `craft_assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_kpguajkygtupxhtphxrfmnciivefdixnfeks` (`sessionId`,`volumeId`),
  KEY `craft_idx_cqchvxedekrldgtslwaagcrtgvfufyjdvanr` (`volumeId`),
  CONSTRAINT `craft_fk_gizjlkwohgpothuvqftplakxvkblyowhllxa` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_jgrqdalniartduahgqwtbhutecmwyutelowq` FOREIGN KEY (`sessionId`) REFERENCES `craft_assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_assetindexingsessions`;
CREATE TABLE `craft_assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_assets`;
CREATE TABLE `craft_assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_kyzbyrsoydlbiefmtpfbwilmestarqjuthtk` (`filename`,`folderId`),
  KEY `craft_idx_hnospdlkajseewesojpctzmdatxpxetxhhnm` (`folderId`),
  KEY `craft_idx_zzbovnqmsbfmivfxsjtdivteyqrgitknznzf` (`volumeId`),
  KEY `craft_fk_kdwqgldccmgdlbqkkhgyvbbgtpjhgxrnwpam` (`uploaderId`),
  CONSTRAINT `craft_fk_bxweepdkpogfdjlgnysssefjojyryqakvybu` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_kdwqgldccmgdlbqkkhgyvbbgtpjhgxrnwpam` FOREIGN KEY (`uploaderId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_sevqvextarfuwxodwyjmvlgjunsznwqfsbxh` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_xwqwtmshlwtdjgfsspalrvvqirsnkkerwrqs` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_assets_sites`;
CREATE TABLE `craft_assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `craft_fk_dxqabxajpwymuaipkkcufpircuttjbmoefbb` (`siteId`),
  CONSTRAINT `craft_fk_dxqabxajpwymuaipkkcufpircuttjbmoefbb` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_idsvoadcfeiknurdqcycfkoicpilqypsfole` FOREIGN KEY (`assetId`) REFERENCES `craft_assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_authenticator`;
CREATE TABLE `craft_authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_fk_tryekpoferoqygdorndpmbqxxmymnzujkkoj` (`userId`),
  CONSTRAINT `craft_fk_tryekpoferoqygdorndpmbqxxmymnzujkkoj` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_bulkopevents`;
CREATE TABLE `craft_bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `craft_idx_ltfqobbnrogluotfpayqjmegzqazjkeauhlz` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_categories`;
CREATE TABLE `craft_categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_asoshtrdkwmipwybdxoqywbyqcqlhzsbqzem` (`groupId`),
  KEY `craft_fk_weagmepzvuatrgdiejqsghsgubzznjjmahbp` (`parentId`),
  CONSTRAINT `craft_fk_weagmepzvuatrgdiejqsghsgubzznjjmahbp` FOREIGN KEY (`parentId`) REFERENCES `craft_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_wxngzdulxqlajumhllxjctkbbuxpsgtlhoqd` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_yquhixaytmyklchwkbfbcavllgmkbpaaqvnf` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_categorygroups`;
CREATE TABLE `craft_categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_xasjtwebubtrnufzcchboouiqtglycosntjz` (`name`),
  KEY `craft_idx_dujcumtluernazhvauytdszywpndiwnyydkl` (`handle`),
  KEY `craft_idx_ramckgurfyqmdwhglwxhxedcbdloimjqkwvi` (`structureId`),
  KEY `craft_idx_vsvozqweyaffbezgiblqmohufccesdcixjrl` (`fieldLayoutId`),
  KEY `craft_idx_xdyzhbijqfqcihmibxpnpwjcdelhibrlvljl` (`dateDeleted`),
  CONSTRAINT `craft_fk_nmbwrrerfeshgsdyveikzkfqypdfolxayzkj` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_vwhklkonpwxyuffmbzjpfnlhgshnwjdosaqa` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_categorygroups_sites`;
CREATE TABLE `craft_categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_zxdhrmeudscdvyuqcyacxgjytvwfprvnltcr` (`groupId`,`siteId`),
  KEY `craft_idx_ezhjzvmdzshaxjkssanzlvuahucjyoxkxfxj` (`siteId`),
  CONSTRAINT `craft_fk_juqyhfgjhomptdnycqfccgcxbugqjpsdcojb` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_wimunimhgbzijnaksgpstybqhezzhxazzymt` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_changedattributes`;
CREATE TABLE `craft_changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `craft_idx_zlmsbzzcxeehlekgoiochhuwqzkhvmquopzm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `craft_fk_qljwryjyunhbpcdcagqpbzqefwvkyxmyzmnu` (`siteId`),
  KEY `craft_fk_yngyovaoqsanemcqjnlyhmjdstcwrlrqwrbc` (`userId`),
  CONSTRAINT `craft_fk_arvnswezryowboehdcqyplrzwbsfiyjtfdpd` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_qljwryjyunhbpcdcagqpbzqefwvkyxmyzmnu` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_yngyovaoqsanemcqjnlyhmjdstcwrlrqwrbc` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_changedfields`;
CREATE TABLE `craft_changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `craft_idx_otvznqftqbmmwqsxlbtltxqvfnhgngzdhtge` (`elementId`,`siteId`,`dateUpdated`),
  KEY `craft_fk_lkpckzdwmrnovaonrahxxgiuoerkrbudbcro` (`siteId`),
  KEY `craft_fk_urtxgqjwlhkgyprdsbtfmwlwoueuyglygidd` (`fieldId`),
  KEY `craft_fk_vcjzrbyydqrtyrgmwyhucjqvbrverplrisls` (`userId`),
  CONSTRAINT `craft_fk_lkpckzdwmrnovaonrahxxgiuoerkrbudbcro` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_ueihkxudkcisvmolznlksvuxgojmjxyjuyta` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_urtxgqjwlhkgyprdsbtfmwlwoueuyglygidd` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_vcjzrbyydqrtyrgmwyhucjqvbrverplrisls` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_contentblocks`;
CREATE TABLE `craft_contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_pxbngsboqfzhplvxoduzwxjntwqhyrmsjdch` (`primaryOwnerId`),
  KEY `craft_idx_dtnwvswdfszrbpvrthnnqblstgugtdsasjsj` (`fieldId`),
  CONSTRAINT `craft_fk_lnncnwoxesbugpndtwpkithebqklvcdyacbc` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_nekkjpwmvkswmyhgezntdapvuiklwaplhiqt` FOREIGN KEY (`primaryOwnerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_rdcwevblsgzibrunplxibfxxqxxmnstuqijj` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_craftidtokens`;
CREATE TABLE `craft_craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fk_ircffxkjojqelnrpahjsadvewgxquydgbpfb` (`userId`),
  CONSTRAINT `craft_fk_ircffxkjojqelnrpahjsadvewgxquydgbpfb` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_deprecationerrors`;
CREATE TABLE `craft_deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_jkefnrrikhmvpqcghphecksdymmdnacphrli` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_drafts`;
CREATE TABLE `craft_drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `craft_idx_umpjlwnqshrjulwihkpywdvwnvquhssjaedj` (`creatorId`,`provisional`),
  KEY `craft_idx_sdhqctlpghcbgpxrjkbbhnhaneefqblhfuak` (`saved`),
  KEY `craft_fk_ydrflnezxaltybeynlnetansyfqmrpgzgcat` (`canonicalId`),
  CONSTRAINT `craft_fk_emaqvbbelkbfvzvkgzssgrhevnhmfdrkulky` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_ydrflnezxaltybeynlnetansyfqmrpgzgcat` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_elementactivity`;
CREATE TABLE `craft_elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `craft_idx_abnuoakfdbjuaaejyfrfpdlwalromcjbpaqn` (`elementId`,`timestamp`,`userId`),
  KEY `craft_fk_ajrapavowesxbyyeklildrimrirtdkpmprit` (`userId`),
  KEY `craft_fk_wbnxphsugwcrngnqhchbjnwodhinbwktzunb` (`siteId`),
  KEY `craft_fk_dqvioibyykctywbzvfekpimlrazyuxvsjndc` (`draftId`),
  CONSTRAINT `craft_fk_ajrapavowesxbyyeklildrimrirtdkpmprit` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_dqvioibyykctywbzvfekpimlrazyuxvsjndc` FOREIGN KEY (`draftId`) REFERENCES `craft_drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_qqzucfrexrhwpdmsgmevozishttyhzuctafj` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_wbnxphsugwcrngnqhchbjnwodhinbwktzunb` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_elements`;
CREATE TABLE `craft_elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_nreygrwjeecllmihkscyrvlhqizjykpwcasc` (`dateDeleted`),
  KEY `craft_idx_hthevxqyoficdrcioetvoxgrympnrwjkhzao` (`fieldLayoutId`),
  KEY `craft_idx_wlajthcgckehvwhbliektuyvicwfkxgvgrnj` (`type`),
  KEY `craft_idx_ocgkusaanxjyhflpbnhznzyeajlsnvejthic` (`enabled`),
  KEY `craft_idx_maxxwlqckghvdpoogfccvqezsuhfwstqrkrp` (`canonicalId`),
  KEY `craft_idx_zxdrocmvrpzusrnujzynmjcolbqbzpurlrjq` (`archived`,`dateCreated`),
  KEY `craft_idx_uquwumzngmwuamtfqgmpfootultyhsfmaygt` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `craft_idx_gwojasmjrhhrsxrpxkstrjszxffiyrxrbfyp` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `craft_fk_kbsisfyuxynghmzurnslljbkgpjmldwssyru` (`draftId`),
  KEY `craft_fk_wudjbxtilumtypkhkuuwydbxspaowvyeljmh` (`revisionId`),
  CONSTRAINT `craft_fk_kbsisfyuxynghmzurnslljbkgpjmldwssyru` FOREIGN KEY (`draftId`) REFERENCES `craft_drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_rsegtiydtacvdeaigqlysgmupqwxfwcynbgh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_wudjbxtilumtypkhkuuwydbxspaowvyeljmh` FOREIGN KEY (`revisionId`) REFERENCES `craft_revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_xdxgjrpvdjhxwmwdzvzhbunveakksoqvkqmk` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_elements_bulkops`;
CREATE TABLE `craft_elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `craft_idx_fsrnouagoyycyirnfkchlmefrgsnxuzvwdcq` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_elements_owners`;
CREATE TABLE `craft_elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `craft_fk_pdvbfrkzwmczdrjozpcwiwwlwzldrxiugsyh` (`ownerId`),
  CONSTRAINT `craft_fk_chgftmwhtwepnmxwqhydhrpuehwleewwcymr` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_pdvbfrkzwmczdrjozpcwiwwlwzldrxiugsyh` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_elements_sites`;
CREATE TABLE `craft_elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_eghpmjszonbjpwtumajuwqvtuxhdtesvzznd` (`elementId`,`siteId`),
  KEY `craft_idx_nimqydzrdkxniicxldokifpxbtcnhfanarau` (`siteId`),
  KEY `craft_idx_ykjumwzqbursucvzhtnnbxdtxhpgolbqhwhy` (`title`,`siteId`),
  KEY `craft_idx_ptqfcsvbtagnvkviskponlnhcvkexzcqjilb` (`slug`,`siteId`),
  KEY `craft_idx_odcxqxssxordwigkbkgttctomkclwpcepyxk` (`enabled`),
  KEY `craft_idx_hjuarolqlwhlmsdmxqbtieyxgcrkyosxlxuv` (`uri`,`siteId`),
  CONSTRAINT `craft_fk_hqmfjvsuriqqxwpevmsojjjscqgdmhlhvxrp` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_morhnakffkmuqdnnvgnwwzgblgysjsvcxabt` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_entries`;
CREATE TABLE `craft_entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_iislobrnxolcrgzyjskbvhybuwwndnnedhtn` (`postDate`),
  KEY `craft_idx_zutolomdoiuezkeazqluqxkseabryxgghyzz` (`expiryDate`),
  KEY `craft_idx_midiihwwtboosywxipmryweyutscbqqvjgbl` (`status`),
  KEY `craft_idx_xkpwnopsfbyqjhumjvbjawbjyyvtixcwgfmx` (`sectionId`),
  KEY `craft_idx_benlfdiattjxyjzoltsknfxgobjtxgwdlchb` (`typeId`),
  KEY `craft_idx_oewngaemmfskppcutsmfkhcqplucymkjcvhm` (`primaryOwnerId`),
  KEY `craft_idx_gzfymbdqwcsmxaodxsjspbosacpehkqiklyt` (`fieldId`),
  KEY `craft_fk_kvzbzeqxabjubqyeyklrrafjbaytfyijwdrr` (`parentId`),
  CONSTRAINT `craft_fk_attclxxapkhfaeeuzkthregjffninetlqehg` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_bgidwgtybimqajwcmfhmyamsmgxhlquocpfv` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_kvtuxqeztxivuvztdqrjrfqgwcluwhsmxeir` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_kvzbzeqxabjubqyeyklrrafjbaytfyijwdrr` FOREIGN KEY (`parentId`) REFERENCES `craft_entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_toaumhwacccylcwyvrrzpkzhczdetvrotgsw` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_uadzjjnzyjqkhjyrbbqmdacbhpoepbyifgai` FOREIGN KEY (`primaryOwnerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_entries_authors`;
CREATE TABLE `craft_entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `craft_idx_njdudhjxsvwfohitgjqouusfsxiqllldqorb` (`authorId`),
  KEY `craft_idx_izhzwlohsroxhyhuilxniyaopkqeapjatymn` (`entryId`,`sortOrder`),
  CONSTRAINT `craft_fk_hutjvabsibflplmpxjfzknbtzqjplywiruye` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_rblxzqayfqooqgdoezglzhiyrupbnjedfyxr` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_entrytypes`;
CREATE TABLE `craft_entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_byxtkewsobjnkrxzdvwokdiomrvbonlxwdxp` (`fieldLayoutId`),
  KEY `craft_idx_akwfixqwaonoycakijxztvxukkudrkgjrmii` (`dateDeleted`),
  CONSTRAINT `craft_fk_zfimdpcmdhpculpwkbesdweyyzuoyimqvwge` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_fieldlayouts`;
CREATE TABLE `craft_fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_jykvkigtolmpijfxlrdyzqlkzsrgityuimqv` (`dateDeleted`),
  KEY `craft_idx_gqrtjxigogqpudpivxzdwnmutmwnmxctktqp` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_fields`;
CREATE TABLE `craft_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_kfidppwbjupazmbenryretoplenbucowtaqp` (`handle`,`context`),
  KEY `craft_idx_dphxabdrmgnqdjolilqlztueiybxijyegpju` (`context`),
  KEY `craft_idx_bnxrwxlxhmypgvdgecgguijozmpuunbuuqdo` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_globalsets`;
CREATE TABLE `craft_globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_zrxkgewubtftwypkawjbohkkdlicoovlwuag` (`name`),
  KEY `craft_idx_jculrrdxyejwhmaculnlwohhfiqkbztwpagh` (`handle`),
  KEY `craft_idx_nvnjfhzaiaozjwlgewtzzsodshdrgltfcpfl` (`fieldLayoutId`),
  KEY `craft_idx_qbigtsefeauznagpjfqkuorxpcekvpnxyvln` (`sortOrder`),
  CONSTRAINT `craft_fk_bforfpnbvmltadpjwikrcrpkugaygaupxzcg` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_ncoyxmvyolrkdyhqmzoknfqiybqctvxdjcxh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_gqlschemas`;
CREATE TABLE `craft_gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_gqltokens`;
CREATE TABLE `craft_gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_wpevlvmqwqtlvgltecprorwikxiqecllflvl` (`accessToken`),
  UNIQUE KEY `craft_idx_lrcqmmktkwkfykjekhjehtaayhruugwemjge` (`name`),
  KEY `craft_fk_lmrptjuqypqobiordbjvylutstpqcbqumknu` (`schemaId`),
  CONSTRAINT `craft_fk_lmrptjuqypqobiordbjvylutstpqcbqumknu` FOREIGN KEY (`schemaId`) REFERENCES `craft_gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_imagetransformindex`;
CREATE TABLE `craft_imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_jvudsimoexalcltllspigknogbkwbovrfdlx` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_imagetransforms`;
CREATE TABLE `craft_imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_tkrvtnktftewweiqowrchclmzcvkutdhmoge` (`name`),
  KEY `craft_idx_yxpeuisgjxnelaghslngwqztuziiartztvnb` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_info`;
CREATE TABLE `craft_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `craft_info` (`id`, `version`, `schemaVersion`, `maintenance`, `configVersion`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1,	'5.8.23',	'5.8.0.3',	0,	'hiwgekulraqc',	'3@shgjbpmkyy',	'2026-03-08 23:13:33',	'2026-03-08 23:13:40',	'a5fb3475-2a24-4f63-b5ed-1cfedab72968');

DROP TABLE IF EXISTS `craft_migrations`;
CREATE TABLE `craft_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_rskqujqgzsicttwmhjugwtwupfqlcepprbmj` (`track`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_plugins`;
CREATE TABLE `craft_plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_yfenefhvysgfqfhgqdhmbbkpoynyddtncqtk` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_projectconfig`;
CREATE TABLE `craft_projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_queue`;
CREATE TABLE `craft_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_idx_hlqdrikfnjrwhcyodkeiouvkhhqobgpyzlys` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `craft_idx_fhinuombpykdxpkehlmweussweirttiyuglr` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_recoverycodes`;
CREATE TABLE `craft_recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_relations`;
CREATE TABLE `craft_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_stxxwrvkptknzshktqlggjhdqemvwuvrkeih` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `craft_idx_gmjuojrabefzchlaunnqveovhqeheyzgicwf` (`sourceId`),
  KEY `craft_idx_yiakrlmzonbujmxfahivcqpnxenjdvqeicby` (`targetId`),
  KEY `craft_idx_mfobihtlkyqjzgzwynmniteoxtngbeqrpasa` (`sourceSiteId`),
  CONSTRAINT `craft_fk_anskoaupdehwxyonsttssxpqurnygiykqsbg` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_dowelacqkeerkrulheywgvqfjtytmcyrvifx` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_oxfrbezebpvypymcsikdwghziunchvyrnxfn` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_resourcepaths`;
CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_revisions`;
CREATE TABLE `craft_revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_fhcrhskhmygsasxgsqiexxrpjvrhhzzssolo` (`canonicalId`,`num`),
  KEY `craft_fk_sfzmcxghjxsruhboxddtiutxvzaeywiotlbh` (`creatorId`),
  CONSTRAINT `craft_fk_esdlmvnzosuwbfvvvvuwqaobksbdnnosvufs` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_sfzmcxghjxsruhboxddtiutxvzaeywiotlbh` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_searchindex`;
CREATE TABLE `craft_searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `craft_idx_tkippmlmzkjkfzhmfuumnzeiehknalizldva` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_searchindexqueue`;
CREATE TABLE `craft_searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_ulsgwprwilailkhwfxkrofojqwpdwtldtqxw` (`elementId`,`siteId`,`reserved`),
  CONSTRAINT `craft_fk_pmvfgvofbhaytsktpnetotiokzgztrcaaeuh` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_searchindexqueue_fields`;
CREATE TABLE `craft_searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `craft_idx_ahyxchkkpczhwgtbbdnrakmduhapddvyuglx` (`jobId`,`fieldHandle`),
  CONSTRAINT `craft_fk_dljqvzscputzpskwdykfouswwogkkadqogjl` FOREIGN KEY (`jobId`) REFERENCES `craft_searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sections`;
CREATE TABLE `craft_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_izehewohmvfxurtyjberodxflkkxzqpjzidw` (`handle`),
  KEY `craft_idx_bcyikwybrkvnnkgypyvdsrgvoqvktrvjiprn` (`name`),
  KEY `craft_idx_vkywphbhgfbuoytozybnjaciwbgfesgbrmsb` (`structureId`),
  KEY `craft_idx_fjkzmsfgdrstqyamdsdojpthiiakqiaeivas` (`dateDeleted`),
  CONSTRAINT `craft_fk_dzwomwccwbwsjkhymhqstushrrchbcufpovg` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sections_entrytypes`;
CREATE TABLE `craft_sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `craft_fk_jbcngbputjckmgtjeifuyvlefgvpwjbitmty` (`typeId`),
  CONSTRAINT `craft_fk_jbcngbputjckmgtjeifuyvlefgvpwjbitmty` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_jnraslsxdjccpuolnzdonxylryksdygxojwk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sections_sites`;
CREATE TABLE `craft_sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_oqbsszxeztzqgmnklxmljaykgcnodkzjpyod` (`sectionId`,`siteId`),
  KEY `craft_idx_iprsillyxsxgkzetcrjiwugasxyyywhlpdkm` (`siteId`),
  CONSTRAINT `craft_fk_hkqkpieydnuzkerenwxnxwarzbajdouvplxh` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_vmmbqjndtccxyjodyhuzbhsiybfyosplkcse` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sequences`;
CREATE TABLE `craft_sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sessions`;
CREATE TABLE `craft_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_cewhmhbsamlpahdhpewpahcefmfwnngvvsry` (`uid`),
  KEY `craft_idx_bsytmacbphanodlogmfpcprhwuksnnikubfu` (`token`),
  KEY `craft_idx_nqmhfmtzmigpkchsgacwuilnbbhzkvlafhmi` (`dateUpdated`),
  KEY `craft_idx_jaljjjvntibtpaxesgbemnlogbstrernpnrl` (`userId`),
  CONSTRAINT `craft_fk_ezbycbpbqgavazqikyevtbtzslztnmxslxmq` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_shunnedmessages`;
CREATE TABLE `craft_shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_jkctgpcrjabvfczgihbtnpjjhfqwshlbrxht` (`userId`,`message`),
  CONSTRAINT `craft_fk_nvdlglsaukzhmfrdihumwpwqcrgamctrzknr` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sitegroups`;
CREATE TABLE `craft_sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_xwwmftgstuwpacboehmrwiwnhprtyrdufrop` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sites`;
CREATE TABLE `craft_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_bmmyvkvdvinahfsiljisburrbtuipoyvkgqa` (`dateDeleted`),
  KEY `craft_idx_vviyneowjpojtoresojwwctwakzdgxcoeqka` (`handle`),
  KEY `craft_idx_wsgqxitjvqyosgntajfslhuzxvzyjcmckryx` (`sortOrder`),
  KEY `craft_fk_bakfadxdukfrfxjphdricnnxabkxgzvwfjif` (`groupId`),
  CONSTRAINT `craft_fk_bakfadxdukfrfxjphdricnnxabkxgzvwfjif` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_sso_identities`;
CREATE TABLE `craft_sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `craft_fk_ibjpjrnzsgkhbgrkiebctvwlvizrdlmuoqsp` (`userId`),
  CONSTRAINT `craft_fk_ibjpjrnzsgkhbgrkiebctvwlvizrdlmuoqsp` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_structureelements`;
CREATE TABLE `craft_structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_pcwtkcugtxpjahfonwvvawqdflwomqzdjwrh` (`structureId`,`elementId`),
  KEY `craft_idx_wmqvmssutxxvuotlbinpgtkepgpigldmrrgg` (`root`),
  KEY `craft_idx_nkmawzdgiglnelpsxhrrkuhjtocdbzeapcem` (`lft`),
  KEY `craft_idx_ysbpmelujuppwhttzybxoxyvagvzugtzytxv` (`rgt`),
  KEY `craft_idx_xbhcbuxwgedbhboyywpyvibyhadmloqxmllb` (`level`),
  KEY `craft_idx_ajddsiqgtrhezkkhdeqelxppbpnukvtansmw` (`elementId`),
  CONSTRAINT `craft_fk_cakjveidglozmzqyfdeizqgftsfnheeqnhxi` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_structures`;
CREATE TABLE `craft_structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_bjuivtllgiupyxddkvopujnquubbbckkdgzj` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_systemmessages`;
CREATE TABLE `craft_systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_ntpclzmzdkfhbebvacrrbgajqfkgdmojqfsk` (`key`,`language`),
  KEY `craft_idx_ehwkfcoxnmreliqsdvejpmcrwaywehqiyvzt` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_taggroups`;
CREATE TABLE `craft_taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_iponcurjrbalthkdvykbblsrshyxljwplbob` (`name`),
  KEY `craft_idx_hhbiluwkgrfnstrmcppsstjqwiukppkydmct` (`handle`),
  KEY `craft_idx_ndmgeiunjkebahpbypavjdzgnhzckpbcooji` (`dateDeleted`),
  KEY `craft_fk_fiisxopdnrvvnywmbscdnkizhvhbfueqnakh` (`fieldLayoutId`),
  CONSTRAINT `craft_fk_fiisxopdnrvvnywmbscdnkizhvhbfueqnakh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_tags`;
CREATE TABLE `craft_tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_qfszwunbblrwurbyhjfdarhgmnsnekjqhbop` (`groupId`),
  CONSTRAINT `craft_fk_hqozgjkhhsgqnixjtmssaxruoquqbvvpfrfw` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_yekjqrawkfsaqwnmvfpuynginywgfscmkqpd` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_tokens`;
CREATE TABLE `craft_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_vqvfidymvgnqjnikhhqhhwmymlveamtnotny` (`token`),
  KEY `craft_idx_nvogyhnnyeaszrchymispqswmwctbsqlhiez` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_usergroups`;
CREATE TABLE `craft_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_yychzzmfhdcsuuaubiqgopmlwthqnlxyoawo` (`handle`),
  KEY `craft_idx_tikhdioxkmmdvlqcwaznpiotlamwcrrmpfxx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_usergroups_users`;
CREATE TABLE `craft_usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_qqlshxzumwjqpstuhfofzefutraxvvpdasyy` (`groupId`,`userId`),
  KEY `craft_idx_boyslewaqvpilzvizcjgbjbadjgkbqtpefht` (`userId`),
  CONSTRAINT `craft_fk_bjnpoaelkgwrcfkitvjpovcxavzfqsppkjtu` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_dvsilotbsfxsbkcqtdspnlfprkankdowfqsu` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_userpermissions`;
CREATE TABLE `craft_userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_aecrtoibxjnmnxxhkdkopqesddrzcddbazby` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;
CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_bqujokjvgdeslygubwujxejjocdpzvrhgpce` (`permissionId`,`groupId`),
  KEY `craft_idx_wmjpnlvzacnydcycxfqxalwoforuarxccbud` (`groupId`),
  CONSTRAINT `craft_fk_eqczugjuhlnopukvvemevuwwbfxnlpeweigw` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_qdqemblxekwlpbamkbdkdyjmpfimjngmhmpn` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_userpermissions_users`;
CREATE TABLE `craft_userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_ymsuzkflhjrzbxzwvxkezkcsmjioqlqbtyzq` (`permissionId`,`userId`),
  KEY `craft_idx_xzezegtwqwzakwrwcsedaqmwqabqsvuectqu` (`userId`),
  CONSTRAINT `craft_fk_jhjwrqagubwlurokpmrevwweosnswszfsvhh` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_wghmroaoeytpushhvlusufegpokwyvxkpqrt` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_userpreferences`;
CREATE TABLE `craft_userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `craft_fk_ufrzvuvtcpkwbzwtjauoxlxbmmnnbrfbaxzf` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_users`;
CREATE TABLE `craft_users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_wqhakujobibaxzunjwwkmsqrmlfndznwchje` (`active`),
  KEY `craft_idx_qyogzcaagnljnyrvjzowimaqkpnucdrmmmir` (`locked`),
  KEY `craft_idx_jozometodhuehjpapckmxnlvpjraaiuhjeew` (`pending`),
  KEY `craft_idx_pwrngcnszpyvboooreopgkmkdhogwcmjkuee` (`suspended`),
  KEY `craft_idx_ngtjmjojnjjcemdwbrwwtzpgxrfwntwotsde` (`verificationCode`),
  KEY `craft_idx_gwzzuakdsurrpzwmqadcivxjdcmiogwodpyt` (`email`),
  KEY `craft_idx_tzoqijngzgjfedhqqzgovtbyjacazhblavxr` (`username`),
  KEY `craft_fk_asbzkwqsmwcriyftkvtvywhevxebjznxxjku` (`photoId`),
  KEY `craft_fk_sidjhuynnjcmiflfqkzywzqxyjchucunevvh` (`affiliatedSiteId`),
  CONSTRAINT `craft_fk_asbzkwqsmwcriyftkvtvywhevxebjznxxjku` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_sidjhuynnjcmiflfqkzywzqxyjchucunevvh` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_urjocgxksrmoikntsozjiwnfqwrpabibwzgn` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `craft_users` (`id`, `photoId`, `affiliatedSiteId`, `active`, `pending`, `locked`, `suspended`, `admin`, `username`, `fullName`, `firstName`, `lastName`, `email`, `password`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`) VALUES
(1,	NULL,	NULL,	1,	0,	0,	0,	1,	'craft@example.com',	NULL,	NULL,	NULL,	'craft@example.com',	'$2y$13$a6AxcyQuL8rtJylLqyRFTuwF7KHrr6GnRFbxBinZo6WjK9hy6a7oC',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	NULL,	NULL,	NULL,	0,	'2026-03-08 23:13:37',	'2026-03-08 23:13:37',	'2026-03-08 23:13:37');

DROP TABLE IF EXISTS `craft_volumefolders`;
CREATE TABLE `craft_volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_motfpwslvgdymcjyyxsqnqfacgefxqsjxjbf` (`name`,`parentId`,`volumeId`),
  KEY `craft_idx_jumypolmnidtnyuyrooseryepwtntqihvpwi` (`parentId`),
  KEY `craft_idx_rrwewpxhtcdmftzcpnmexbvwqcigmbsaedsh` (`volumeId`),
  CONSTRAINT `craft_fk_bcxipnohtjnzbhnmpusctnevkzvyrmlgbajg` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_hjnmnpffmuemfbvzzwemkzyfckcmldqaciaz` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_volumes`;
CREATE TABLE `craft_volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_oxtkiqpfsdtvqnaoixqgnrofzoepouuejvkb` (`name`),
  KEY `craft_idx_fhtdgyzykpcenseffzczmubaceolatgnlwqz` (`handle`),
  KEY `craft_idx_brmmdklkpmtshshaaxxpwfkywspzpijaitvo` (`fieldLayoutId`),
  KEY `craft_idx_suzgquurclexlyizdftkdltztqleyjjnfcrb` (`dateDeleted`),
  CONSTRAINT `craft_fk_mkdfvgcxngexciytvqtsjfrfuboxfzrtqcty` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_webauthn`;
CREATE TABLE `craft_webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fk_rmenrqmqovpmwlixdknstmutjbgkefextzvz` (`userId`),
  CONSTRAINT `craft_fk_rmenrqmqovpmwlixdknstmutjbgkefextzvz` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `craft_widgets`;
CREATE TABLE `craft_widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_idcqlutqkvorotjmkhfrnvbxtjkxcvjfivus` (`userId`),
  CONSTRAINT `craft_fk_cttkqinhxfuyayiizkgfynvizfxsaepfqftt` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2026-03-08 23:20:45
